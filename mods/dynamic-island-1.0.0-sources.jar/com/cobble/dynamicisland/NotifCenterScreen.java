package com.cobble.dynamicisland;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Transparent screen for the Notification Center — captures scroll, clicks, and keyboard.
 * Has 3 tabs: Notifications, Waypoints, Timers.
 * All rendering done by DynamicIslandHud.
 */
public class NotifCenterScreen extends class_437 {

    public NotifCenterScreen() {
        super(class_2561.method_43470("Notifications"));
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_N) {
            DynamicIslandMod.isNotifCenterOpen = false;
            this.method_25419();
            return true;
        }
        // C to clear notifications (only on notifications tab)
        if (keyCode == GLFW.GLFW_KEY_C && DynamicIslandMod.notifCenterTab == 0) {
            DynamicIslandMod.notifHistory.clear();
            DynamicIslandMod.notifCenterScroll = 0;
            return true;
        }
        // Tab switching with 1, 2, 3
        if (keyCode == GLFW.GLFW_KEY_1) { DynamicIslandMod.notifCenterTab = 0; DynamicIslandMod.notifCenterScroll = 0; return true; }
        if (keyCode == GLFW.GLFW_KEY_2) { DynamicIslandMod.notifCenterTab = 1; DynamicIslandMod.notifCenterScroll = 0; return true; }
        if (keyCode == GLFW.GLFW_KEY_3) { DynamicIslandMod.notifCenterTab = 2; DynamicIslandMod.notifCenterScroll = 0; return true; }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        DynamicIslandMod.notifCenterScroll += (int)(verticalAmount * 20);
        return true;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Forward clicks to HUD for waypoint/timer/tab handling
        DynamicIslandMod.notifClickX = (int) mouseX;
        DynamicIslandMod.notifClickY = (int) mouseY;
        DynamicIslandMod.notifClickButton = button;
        DynamicIslandMod.notifClickPending = true;
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {}

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {}

    @Override
    public boolean method_25421() { return false; }
}
