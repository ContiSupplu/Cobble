package com.cobble.dynamicisland;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_9362;
import net.minecraft.item.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Tracks combat state: detects when player is attacked OR attacks another player.
 * Shows opponent info including armor pieces with durability, weapon, health, potion effects.
 * 20-second timeout, resets on each hit in either direction.
 * Kill celebration when opponent dies during combat.
 */
public class CombatTracker {

    private static final long COMBAT_TIMEOUT_MS = 20000; // 20 seconds
    private static final double MAX_COMBAT_RANGE = 50.0;

    // Combat state
    public static boolean inCombat = false;
    public static long lastCombatTime = 0;
    public static class_1309 opponent = null;
    public static String opponentName = null;
    public static float opponentHealth = 0;
    public static float opponentMaxHealth = 0;
    public static String opponentWeaponName = null;
    public static class_2960 opponentSkinTexture = null;

    // Individual armor pieces
    public static class_1799 opponentHelmet = class_1799.field_8037;
    public static class_1799 opponentChestplate = class_1799.field_8037;
    public static class_1799 opponentLeggings = class_1799.field_8037;
    public static class_1799 opponentBoots = class_1799.field_8037;
    public static class_1799 opponentWeaponStack = class_1799.field_8037;
    public static class_1799 opponentOffhand = class_1799.field_8037;

    // Potion effects
    public static List<String> opponentEffects = new ArrayList<>();

    // Kill celebration
    public static boolean killCelebration = false;
    public static long killCelebrationTime = 0;
    public static String killedPlayerName = null;
    private static final long CELEBRATION_DURATION_MS = 3000;

    public static void register() {
        // Tick-based combat tracking
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) return;
            tick(client);
        });

        // Melee attack detection (player attacking others)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.field_9236 && entity instanceof class_1309 living) {
                if (living instanceof class_742) {
                    enterCombat(living);
                }
            }
            return class_1269.field_5811;
        });
    }

    private static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) return;

        // --- Kill celebration timeout ---
        if (killCelebration) {
            if (System.currentTimeMillis() - killCelebrationTime > CELEBRATION_DURATION_MS) {
                killCelebration = false;
                killedPlayerName = null;
                endCombat();
            }
            return;
        }

        // --- Detect being hit ---
        if (player.field_6235 > 0) {
            class_1309 attacker = player.method_6065();

            // Fallback: scan nearby players when getAttacker() returns null
            if (attacker == null || !attacker.method_5805()) {
                attacker = findLikelyAttacker(client, player);
            }

            if (attacker != null && attacker.method_5805()) {
                if (isHoldingWeapon(attacker) || player.method_5739(attacker) <= 6.0) {
                    enterCombat(attacker);
                }
            }
        }

        // --- Detect bow/ranged hits (player hitting others with bow) ---
        class_1792 heldItem = player.method_6047().method_7909();
        boolean holdingRanged = heldItem instanceof class_1753 || heldItem instanceof class_1764;
        if (holdingRanged) {
            for (class_742 other : client.field_1687.method_18456()) {
                if (other == player) continue;
                if (!other.method_5805()) continue;
                // Just got hit (first frame of hurt animation)
                if (other.field_6235 >= 9 && player.method_5739(other) <= MAX_COMBAT_RANGE) {
                    enterCombat(other);
                }
            }
        }

        // --- Also detect being hit by arrows (opponent might be far away with bow) ---
        if (player.field_6235 > 0) {
            for (class_742 other : client.field_1687.method_18456()) {
                if (other == player) continue;
                if (!other.method_5805()) continue;
                class_1792 otherHeld = other.method_6047().method_7909();
                if ((otherHeld instanceof class_1753 || otherHeld instanceof class_1764)
                    && player.method_5739(other) <= MAX_COMBAT_RANGE) {
                    enterCombat(other);
                    break;
                }
            }
        }

        // --- Update ongoing combat ---
        if (inCombat && opponent != null) {
            if (!opponent.method_5805()) {
                triggerKillCelebration();
                return;
            }

            if (player.method_5739(opponent) > MAX_COMBAT_RANGE) {
                endCombat();
                return;
            }

            if (System.currentTimeMillis() - lastCombatTime > COMBAT_TIMEOUT_MS) {
                endCombat();
                return;
            }

            updateOpponentStats();
        }
    }

    private static void updateOpponentStats() {
        if (opponent == null) return;
        opponentHealth = opponent.method_6032();
        opponentMaxHealth = opponent.method_6063();
        opponentWeaponName = opponent.method_6047().method_7964().getString();
        opponentWeaponStack = opponent.method_6047().method_7972();
        opponentOffhand = opponent.method_6079().method_7972();

        // Armor pieces
        opponentHelmet = opponent.method_6118(class_1304.field_6169).method_7972();
        opponentChestplate = opponent.method_6118(class_1304.field_6174).method_7972();
        opponentLeggings = opponent.method_6118(class_1304.field_6172).method_7972();
        opponentBoots = opponent.method_6118(class_1304.field_6166).method_7972();

        // Skin texture
        if (opponent instanceof class_742 playerOpponent) {
            opponentSkinTexture = playerOpponent.method_52814().comp_1626();
        }

        // Potion effects — try direct API first
        opponentEffects.clear();
        try {
            for (class_1293 effect : opponent.method_6026()) {
                String key = effect.method_5579().method_55840();
                String name = key.contains(":") ? key.substring(key.indexOf(":") + 1) : key;
                name = name.replace("_", " ");
                if (!name.isEmpty()) {
                    name = name.substring(0, 1).toUpperCase() + name.substring(1);
                }

                int durationTicks = effect.method_5584();
                if (durationTicks > 0 && durationTicks < 999999) {
                    int totalSec = durationTicks / 20;
                    int min = totalSec / 60;
                    int sec = totalSec % 60;
                    name += " " + min + ":" + String.format("%02d", sec);
                }

                int amplifier = effect.method_5578();
                if (amplifier > 0) {
                    name += " " + toRoman(amplifier + 1);
                }

                opponentEffects.add(name);
            }
        } catch (Exception e) {
            // Silently fail if API isn't available
        }

        // Fallback: detect visible states if no effects found
        if (opponentEffects.isEmpty()) {
            if (opponent.method_5767()) opponentEffects.add("Invisible");
            if (opponent.method_5851()) opponentEffects.add("Glowing");
            if (opponent.method_5809()) opponentEffects.add("On Fire");
            if (opponent.method_5624()) opponentEffects.add("Sprinting");
            if (opponent.method_32314()) opponentEffects.add("Frozen");
        }
    }

    private static String toRoman(int num) {
        if (num == 2) return "II";
        if (num == 3) return "III";
        if (num == 4) return "IV";
        if (num == 5) return "V";
        return String.valueOf(num);
    }

    private static boolean isHoldingWeapon(class_1309 entity) {
        class_1799 heldStack = entity.method_6047();
        if (heldStack.method_7960()) return false;

        class_1792 item = heldStack.method_7909();
        return item instanceof class_1829
            || item instanceof class_1743
            || item instanceof class_1753
            || item instanceof class_1764
            || item instanceof class_1835
            || item instanceof class_9362;
    }

    private static class_1309 findLikelyAttacker(class_310 client, class_746 player) {
        if (client.field_1687 == null) return null;

        class_1309 best = null;
        double bestDist = 16.0;
        boolean bestHasWeapon = false;

        for (class_742 other : client.field_1687.method_18456()) {
            if (other == player) continue;
            if (!other.method_5805()) continue;

            double dist = player.method_5739(other);
            if (dist > bestDist && best != null) continue;

            boolean hasWeapon = isHoldingWeapon(other);

            if (best == null
                || (hasWeapon && !bestHasWeapon)
                || (hasWeapon == bestHasWeapon && dist < bestDist)) {
                best = other;
                bestDist = dist;
                bestHasWeapon = hasWeapon;
            }
        }

        return best;
    }

    public static void enterCombat(class_1309 attacker) {
        boolean newOpponent = (opponent == null || !attacker.equals(opponent));

        opponent = attacker;
        opponentName = attacker.method_5477().getString();
        lastCombatTime = System.currentTimeMillis();

        updateOpponentStats();

        if (attacker instanceof class_742 playerAttacker) {
            opponentSkinTexture = playerAttacker.method_52814().comp_1626();
        } else {
            opponentSkinTexture = null;
        }

        if (!inCombat || newOpponent) {
            inCombat = true;
            DynamicIslandMod.triggerSilentNotification(
                "Combat: " + opponentName, "combat"
            );
        }
    }

    private static void triggerKillCelebration() {
        killCelebration = true;
        killCelebrationTime = System.currentTimeMillis();
        killedPlayerName = opponentName != null ? opponentName : "Unknown";
        DynamicIslandMod.triggerSilentNotification(
            "✦ Eliminated " + killedPlayerName + "!", "combat"
        );
    }

    public static boolean isInCombat() {
        if (killCelebration) return true;
        if (!inCombat) return false;
        if (System.currentTimeMillis() - lastCombatTime > COMBAT_TIMEOUT_MS) {
            endCombat();
            return false;
        }
        return true;
    }

    public static boolean isCelebrating() {
        return killCelebration;
    }

    public static void endCombat() {
        inCombat = false;
        opponent = null;
        opponentName = null;
        opponentHealth = 0;
        opponentMaxHealth = 0;
        opponentWeaponName = null;
        opponentSkinTexture = null;
        opponentHelmet = class_1799.field_8037;
        opponentChestplate = class_1799.field_8037;
        opponentLeggings = class_1799.field_8037;
        opponentBoots = class_1799.field_8037;
        opponentWeaponStack = class_1799.field_8037;
        opponentOffhand = class_1799.field_8037;
        opponentEffects.clear();
    }
}
