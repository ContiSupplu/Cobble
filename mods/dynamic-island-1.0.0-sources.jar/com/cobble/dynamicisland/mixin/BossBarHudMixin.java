package com.cobble.dynamicisland.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_332;
import net.minecraft.class_337;
import net.minecraft.class_345;

/**
 * Hides the vanilla boss bar HUD. Boss bars are instead rendered
 * inside the Dynamic Island pill by DynamicIslandHud.
 */
@Mixin(class_337.class)
public class BossBarHudMixin {

    @Shadow @Final
    private Map<UUID, class_345> bossBars;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void cancelRender(class_332 ctx, CallbackInfo ci) {
        // Expose boss bar data for the Dynamic Island, then cancel vanilla rendering
        com.cobble.dynamicisland.BossBarTracker.update(bossBars);
        ci.cancel();
    }
}
