package com.cobble.dynamicisland;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1259;
import net.minecraft.class_345;

/**
 * Stores boss bar data from the mixin for the Dynamic Island HUD to render.
 */
public class BossBarTracker {

    public static final List<BossBarInfo> activeBars = new ArrayList<>();

    public static void update(Map<UUID, class_345> bars) {
        activeBars.clear();
        for (class_345 bar : bars.values()) {
            activeBars.add(new BossBarInfo(
                bar.method_5414().getString(),
                bar.method_5412(),
                bar.method_5420()
            ));
        }
    }

    public static class BossBarInfo {
        public final String name;
        public final float percent;
        public final class_1259.class_1260 color;

        public BossBarInfo(String name, float percent, class_1259.class_1260 color) {
            this.name = name;
            this.percent = percent;
            this.color = color;
        }

        public int getBarColor() {
            return switch (color) {
                case field_5788 -> 0xFFFF55FF;
                case field_5780 -> 0xFF5555FF;
                case field_5784 -> 0xFFFF5555;
                case field_5785 -> 0xFF55FF55;
                case field_5782 -> 0xFFFFFF55;
                case field_5783 -> 0xFFAA00AA;
                case field_5786 -> 0xFFFFFFFF;
            };
        }
    }
}
