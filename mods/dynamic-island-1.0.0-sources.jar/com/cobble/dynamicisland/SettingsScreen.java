package com.cobble.dynamicisland;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Transparent screen for Settings — captures mouse clicks, scroll, and keyboard.
 * All rendering done by DynamicIslandHud.
 */
public class SettingsScreen extends class_437 {

    public SettingsScreen() {
        super(class_2561.method_43470("Settings"));
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_G) {
            DynamicIslandMod.isSettingsOpen = false;
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        DynamicIslandMod.settingsScroll += (int)(verticalAmount * 20);
        return true;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            // Pass click coords to HUD for toggle/button handling
            DynamicIslandMod.settingsClickX = (int) mouseX;
            DynamicIslandMod.settingsClickY = (int) mouseY;
            DynamicIslandMod.settingsClickPending = true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {}

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {}

    @Override
    public boolean method_25421() { return false; }
}
