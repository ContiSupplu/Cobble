package com.cobble.dynamicisland;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1786;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1829;
import net.minecraft.class_1831;
import net.minecraft.class_1835;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_479;
import net.minecraft.class_490;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import java.util.*;

/**
 * Detects swipe gestures on inventory screens and performs actions:
 *   Swipe DOWN  → Sort inventory (consolidate + sort by category)
 *   Swipe UP    → Restore preset layout
 *   Swipe LEFT  → Quick-craft from recipe (remembers last recipe for repeat)
 *   Swipe RIGHT → Dump to chest (except tools/armor/elytra)
 */
public class GestureHandler {

    private static boolean tracking = false;
    private static double startX, startY;
    private static final int MIN_DRAG = 40;

    // Recipe memory
    private static Map<Integer, Integer> lastRecipePattern = null; // gridIndex -> item raw id
    private static int lastGridSize = 0;

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_465<?>)) return;

            ScreenMouseEvents.beforeMouseClick(screen).register((s, mx, my, button) -> {
                if (button == 0) {
                    class_465<?> hs = (class_465<?>) s;
                    int guiLeft = (hs.field_22789 - 176) / 2;
                    int guiRight = guiLeft + 176;
                    if (mx < guiLeft || mx > guiRight) {
                        tracking = true;
                        startX = mx;
                        startY = my;
                    }
                }
            });

            ScreenMouseEvents.beforeMouseRelease(screen).register((s, mx, my, button) -> {
                if (button == 0 && tracking) {
                    tracking = false;
                    double dx = mx - startX;
                    double dy = my - startY;
                    double absDx = Math.abs(dx);
                    double absDy = Math.abs(dy);
                    if (absDx < MIN_DRAG && absDy < MIN_DRAG) return;

                    if (absDy > absDx) {
                        if (dy > 0) onSwipeDown(client);
                        else onSwipeUp(client);
                    } else {
                        if (dx > 0) onSwipeRight(client);
                        else onSwipeLeft(client);
                    }
                }
            });
        });
    }

    // ══════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════

    private static List<class_1735> getPlayerMainSlots(class_1703 handler, class_310 client) {
        List<class_1735> result = new ArrayList<>();
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 == client.field_1724.method_31548()
                    && slot.method_34266() >= 0 && slot.method_34266() <= 35) {
                result.add(slot);
            }
        }
        return result;
    }

    private static void click(class_310 client, int syncId, int slotId) {
        client.field_1761.method_2906(syncId, slotId, 0, class_1713.field_7790, client.field_1724);
    }

    private static void rightClick(class_310 client, int syncId, int slotId) {
        client.field_1761.method_2906(syncId, slotId, 1, class_1713.field_7790, client.field_1724);
    }

    private static void shiftClick(class_310 client, int syncId, int slotId) {
        client.field_1761.method_2906(syncId, slotId, 0, class_1713.field_7794, client.field_1724);
    }

    private static boolean sameItemType(class_1799 a, class_1799 b) {
        if (a.method_7960() || b.method_7960()) return false;
        return class_7923.field_41178.method_10206(a.method_7909()) == class_7923.field_41178.method_10206(b.method_7909());
    }

    // ══════════════════════════════════════════════════
    // SWIPE DOWN → Sort Inventory
    // ══════════════════════════════════════════════════
    private static void onSwipeDown(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        class_437 screen = client.field_1755;
        if (!(screen instanceof class_465<?> hs)) return;

        class_1703 handler = hs.method_17577();
        int syncId = handler.field_7763;
        List<class_1735> slots = getPlayerMainSlots(handler, client);
        int n = slots.size();
        if (n == 0) return;

        // ── Step 1: Consolidate same-item stacks ──
        for (int i = 0; i < n; i++) {
            if (!slots.get(i).method_7681()) continue;
            for (int j = i + 1; j < n; j++) {
                if (!slots.get(j).method_7681()) continue;
                if (sameItemType(slots.get(i).method_7677(), slots.get(j).method_7677())) {
                    int space = slots.get(i).method_7677().method_7914() - slots.get(i).method_7677().method_7947();
                    if (space > 0) {
                        // Pick up j, click on i to combine, put remainder back at j
                        click(client, syncId, slots.get(j).field_7874);
                        click(client, syncId, slots.get(i).field_7874);
                        click(client, syncId, slots.get(j).field_7874);
                    }
                }
            }
        }

        // ── Step 2: Compact (push empties to end) ──
        for (int i = 0; i < n; i++) {
            if (!slots.get(i).method_7681()) {
                for (int j = i + 1; j < n; j++) {
                    if (slots.get(j).method_7681()) {
                        click(client, syncId, slots.get(j).field_7874);
                        click(client, syncId, slots.get(i).field_7874);
                        break;
                    }
                }
            }
        }

        // ── Step 3: Count non-empty items ──
        int itemCount = 0;
        for (int i = 0; i < n; i++) {
            if (slots.get(i).method_7681()) itemCount++;
            else break;
        }

        if (itemCount <= 1) {
            DynamicIslandMod.triggerSilentNotification("Inventory sorted!", "general");
            return;
        }

        // ── Step 4: Selection sort using buffer slot ──
        for (int i = 0; i < itemCount - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < itemCount; j++) {
                if (compareStacks(slots.get(j).method_7677(), slots.get(minIdx).method_7677()) < 0) {
                    minIdx = j;
                }
            }
            if (minIdx == i) continue;

            // Skip swap if same item type (they're already considered equal in sort order)
            if (sameItemType(slots.get(i).method_7677(), slots.get(minIdx).method_7677())) continue;

            // Swap using empty buffer slot at end
            int bufferIdx = itemCount; // first empty slot after items
            if (bufferIdx < n) {
                click(client, syncId, slots.get(i).field_7874);        // pick up from i
                click(client, syncId, slots.get(bufferIdx).field_7874); // place at buffer
                click(client, syncId, slots.get(minIdx).field_7874);    // pick up from minIdx
                click(client, syncId, slots.get(i).field_7874);         // place at i
                click(client, syncId, slots.get(bufferIdx).field_7874); // pick up from buffer
                click(client, syncId, slots.get(minIdx).field_7874);    // place at minIdx
            } else {
                // No buffer — direct swap (only safe for different item types, which we checked)
                click(client, syncId, slots.get(i).field_7874);
                click(client, syncId, slots.get(minIdx).field_7874);
                click(client, syncId, slots.get(i).field_7874);
            }
        }

        DynamicIslandMod.triggerSilentNotification("Inventory sorted!", "general");
    }

    private static int compareStacks(class_1799 a, class_1799 b) {
        boolean ea = a.method_7960(), eb = b.method_7960();
        if (ea && eb) return 0;
        if (ea) return 1;
        if (eb) return -1;
        int ca = getCategoryOrder(a), cb = getCategoryOrder(b);
        if (ca != cb) return ca - cb;
        return a.method_7964().getString().compareTo(b.method_7964().getString());
    }

    // ══════════════════════════════════════════════════
    // SWIPE UP → Restore Preset Layout
    // ══════════════════════════════════════════════════
    private static void onSwipeUp(class_310 client) {
        if (!DynamicIslandMod.hasInventoryPreset || DynamicIslandMod.savedInventoryLayout == null) {
            DynamicIslandMod.triggerSilentNotification("No preset saved! G > Inventory", "general");
            return;
        }
        if (client.field_1724 == null || client.field_1761 == null) return;
        class_437 screen = client.field_1755;
        if (!(screen instanceof class_465<?> hs)) return;

        class_1703 handler = hs.method_17577();
        int syncId = handler.field_7763;
        List<class_1735> slots = getPlayerMainSlots(handler, client);
        int[] preset = DynamicIslandMod.savedInventoryLayout;

        // For each slot in the preset, ensure the right item type is there
        for (int i = 0; i < Math.min(preset.length, slots.size()); i++) {
            int wantedId = preset[i];
            if (wantedId == -1) continue; // preset says empty

            class_1735 targetSlot = slots.get(i);

            // Check if already correct
            if (targetSlot.method_7681()) {
                int currentId = class_7923.field_41178.method_10206(targetSlot.method_7677().method_7909());
                if (currentId == wantedId) continue;
            }

            // Search ALL other slots for this item type (not just j > i)
            int sourceIdx = -1;
            for (int j = 0; j < slots.size(); j++) {
                if (j == i) continue;
                if (slots.get(j).method_7681()) {
                    int srcId = class_7923.field_41178.method_10206(slots.get(j).method_7677().method_7909());
                    if (srcId == wantedId) { sourceIdx = j; break; }
                }
            }
            if (sourceIdx == -1) continue; // item not found anywhere

            if (!targetSlot.method_7681()) {
                // Target is empty — just move source here
                click(client, syncId, slots.get(sourceIdx).field_7874);
                click(client, syncId, targetSlot.field_7874);
            } else {
                // Target has wrong item — need to swap
                // Find an empty slot for buffer
                int emptyIdx = -1;
                for (int e = 0; e < slots.size(); e++) {
                    if (!slots.get(e).method_7681()) { emptyIdx = e; break; }
                }
                if (emptyIdx != -1) {
                    // Move wrong item to buffer
                    click(client, syncId, targetSlot.field_7874);
                    click(client, syncId, slots.get(emptyIdx).field_7874);
                    // Move correct item to target
                    click(client, syncId, slots.get(sourceIdx).field_7874);
                    click(client, syncId, targetSlot.field_7874);
                } else {
                    // No buffer — direct swap (works for different types)
                    click(client, syncId, slots.get(sourceIdx).field_7874);
                    click(client, syncId, targetSlot.field_7874);
                    click(client, syncId, slots.get(sourceIdx).field_7874);
                }
            }
        }

        DynamicIslandMod.triggerSilentNotification("Preset layout restored!", "general");
    }

    // ══════════════════════════════════════════════════
    // SWIPE LEFT → Quick Craft (with recipe memory)
    // ══════════════════════════════════════════════════
    private static void onSwipeLeft(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        class_437 screen = client.field_1755;
        if (!(screen instanceof class_465<?> hs)) return;

        class_1703 handler = hs.method_17577();
        int syncId = handler.field_7763;

        int resultSlotId;
        List<Integer> gridSlotIds = new ArrayList<>();
        int gridSize;

        if (screen instanceof class_479) {
            resultSlotId = 0;
            for (int i = 1; i <= 9; i++) gridSlotIds.add(i);
            gridSize = 9;
        } else if (screen instanceof class_490) {
            resultSlotId = 0;
            for (int i = 1; i <= 4; i++) gridSlotIds.add(i);
            gridSize = 4;
        } else {
            DynamicIslandMod.triggerSilentNotification("Open crafting to quick-craft!", "general");
            return;
        }

        // Check if grid is empty
        boolean gridEmpty = true;
        for (int slotId : gridSlotIds) {
            if (handler.method_7611(slotId).method_7681()) { gridEmpty = false; break; }
        }

        // If grid is empty but we have a stored recipe, fill grid AND craft in one go
        if (gridEmpty && lastRecipePattern != null && lastGridSize == gridSize) {
            craftFromMemory(client, handler, syncId, resultSlotId, gridSlotIds);
            return;
        }

        // Grid has a recipe — read it, save it, craft
        Map<Integer, Integer> recipePattern = new LinkedHashMap<>();
        Map<Integer, Integer> recipeCost = new HashMap<>();
        boolean hasRecipe = false;

        for (int idx = 0; idx < gridSlotIds.size(); idx++) {
            class_1735 gridSlot = handler.method_7611(gridSlotIds.get(idx));
            if (gridSlot.method_7681()) {
                hasRecipe = true;
                int rawId = class_7923.field_41178.method_10206(gridSlot.method_7677().method_7909());
                recipePattern.put(idx, rawId);
                recipeCost.merge(rawId, 1, Integer::sum);
            }
        }

        if (!hasRecipe) {
            DynamicIslandMod.triggerSilentNotification("Place a recipe in the grid first!", "general");
            return;
        }

        class_1735 resultSlot = handler.method_7611(resultSlotId);
        if (!resultSlot.method_7681()) {
            DynamicIslandMod.triggerSilentNotification("Invalid recipe!", "general");
            return;
        }

        // Save recipe for memory
        lastRecipePattern = new LinkedHashMap<>(recipePattern);
        lastGridSize = gridSize;

        // Mass craft
        int crafted = massCraft(client, handler, syncId, resultSlotId, gridSlotIds, recipePattern, recipeCost);

        String resultName = resultSlot.method_7681() ? resultSlot.method_7677().method_7964().getString() : "items";
        DynamicIslandMod.triggerSilentNotification("Crafted " + crafted + "x " + resultName, "general");
    }

    /**
     * Fill grid from memory recipe and mass-craft — all in one swipe.
     */
    private static void craftFromMemory(class_310 client, class_1703 handler, int syncId,
                                         int resultSlotId, List<Integer> gridSlotIds) {
        List<class_1735> playerSlots = getPlayerMainSlots(handler, client);
        Map<Integer, Integer> recipePattern = lastRecipePattern;
        Map<Integer, Integer> recipeCost = new HashMap<>();
        for (Map.Entry<Integer, Integer> entry : recipePattern.entrySet()) {
            recipeCost.merge(entry.getValue(), 1, Integer::sum);
        }

        // Count available materials
        Map<Integer, Integer> available = new HashMap<>();
        for (class_1735 slot : playerSlots) {
            if (slot.method_7681()) {
                int rawId = class_7923.field_41178.method_10206(slot.method_7677().method_7909());
                available.merge(rawId, slot.method_7677().method_7947(), Integer::sum);
            }
        }

        // Check if we have enough for at least 1 craft
        int maxCrafts = Integer.MAX_VALUE;
        for (Map.Entry<Integer, Integer> entry : recipeCost.entrySet()) {
            int have = available.getOrDefault(entry.getKey(), 0);
            if (have < entry.getValue()) {
                DynamicIslandMod.triggerSilentNotification("Not enough materials!", "general");
                return;
            }
            maxCrafts = Math.min(maxCrafts, have / entry.getValue());
        }

        // Fill the grid for first craft
        for (Map.Entry<Integer, Integer> entry : recipePattern.entrySet()) {
            int gridIdx = entry.getKey();
            int itemId = entry.getValue();
            int slotId = gridSlotIds.get(gridIdx);

            for (class_1735 pSlot : playerSlots) {
                if (pSlot.method_7681() && class_7923.field_41178.method_10206(pSlot.method_7677().method_7909()) == itemId) {
                    click(client, syncId, pSlot.field_7874);                        // pick up stack
                    rightClick(client, syncId, slotId);                      // place 1 in grid
                    click(client, syncId, pSlot.field_7874);                        // put rest back
                    break;
                }
            }
        }

        // Now mass-craft (grid is filled, result should appear)
        int crafted = massCraft(client, handler, syncId, resultSlotId, gridSlotIds, recipePattern, recipeCost);

        DynamicIslandMod.triggerSilentNotification("Crafted " + crafted + "x from memory", "general");
    }

    /**
     * Mass-craft: take result, refill grid, repeat until out of materials or space.
     */
    private static int massCraft(class_310 client, class_1703 handler, int syncId,
                                  int resultSlotId, List<Integer> gridSlotIds,
                                  Map<Integer, Integer> recipePattern, Map<Integer, Integer> recipeCost) {
        List<class_1735> playerSlots = getPlayerMainSlots(handler, client);

        // Count all available materials (inventory + grid)
        Map<Integer, Integer> available = new HashMap<>();
        for (class_1735 slot : playerSlots) {
            if (slot.method_7681()) {
                available.merge(class_7923.field_41178.method_10206(slot.method_7677().method_7909()), slot.method_7677().method_7947(), Integer::sum);
            }
        }
        for (int slotId : gridSlotIds) {
            class_1735 gridSlot = handler.method_7611(slotId);
            if (gridSlot.method_7681()) {
                available.merge(class_7923.field_41178.method_10206(gridSlot.method_7677().method_7909()), gridSlot.method_7677().method_7947(), Integer::sum);
            }
        }

        int maxCrafts = Integer.MAX_VALUE;
        for (Map.Entry<Integer, Integer> entry : recipeCost.entrySet()) {
            int have = available.getOrDefault(entry.getKey(), 0);
            maxCrafts = Math.min(maxCrafts, have / entry.getValue());
        }

        // Limit by inventory space
        class_1735 resultSlot = handler.method_7611(resultSlotId);
        if (resultSlot.method_7681()) {
            class_1799 resultStack = resultSlot.method_7677();
            int resultCount = resultStack.method_7947();
            int maxStack = resultStack.method_7914();
            int space = 0;
            for (class_1735 slot : playerSlots) {
                if (!slot.method_7681()) space += maxStack;
                else if (class_1799.method_7984(slot.method_7677(), resultStack))
                    space += maxStack - slot.method_7677().method_7947();
            }
            maxCrafts = Math.min(maxCrafts, Math.max(1, space / resultCount));
        }

        if (maxCrafts <= 0) return 0;

        // Take first result
        shiftClick(client, syncId, resultSlotId);
        int crafted = 1;

        // Repeat: refill grid, take result
        for (int craft = 1; craft < maxCrafts; craft++) {
            boolean canFill = true;
            for (Map.Entry<Integer, Integer> entry : recipePattern.entrySet()) {
                int gridIdx = entry.getKey();
                int slotId = gridSlotIds.get(gridIdx);
                class_1735 gridSlot = handler.method_7611(slotId);

                // Skip if already has correct item
                if (gridSlot.method_7681()) {
                    int currentId = class_7923.field_41178.method_10206(gridSlot.method_7677().method_7909());
                    if (currentId == entry.getValue()) continue;
                }

                // Find material in inventory
                boolean found = false;
                for (class_1735 pSlot : playerSlots) {
                    if (pSlot.method_7681()) {
                        int pId = class_7923.field_41178.method_10206(pSlot.method_7677().method_7909());
                        if (pId == entry.getValue()) {
                            click(client, syncId, pSlot.field_7874);
                            rightClick(client, syncId, slotId);
                            click(client, syncId, pSlot.field_7874);
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) { canFill = false; break; }
            }

            if (!canFill) break;
            shiftClick(client, syncId, resultSlotId);
            crafted++;
        }

        return crafted;
    }

    // ══════════════════════════════════════════════════
    // SWIPE RIGHT → Dump to Chest
    // ══════════════════════════════════════════════════
    private static void onSwipeRight(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        class_437 screen = client.field_1755;
        if (!(screen instanceof class_476)) {
            DynamicIslandMod.triggerSilentNotification("Open a chest first!", "general");
            return;
        }

        class_465<?> hs = (class_465<?>) screen;
        class_1703 handler = hs.method_17577();
        int syncId = handler.field_7763;

        int dumped = 0;
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 != client.field_1724.method_31548()) continue;
            if (!slot.method_7681()) continue;
            if (isProtectedItem(slot.method_7677())) continue;
            shiftClick(client, syncId, slot.field_7874);
            dumped++;
        }

        DynamicIslandMod.triggerSilentNotification("Dumped " + dumped + " stacks to chest", "general");
    }

    // ══════════════════════════════════════════════════
    // ITEM CLASSIFICATION
    // ══════════════════════════════════════════════════

    private static boolean isProtectedItem(class_1799 stack) {
        class_1792 item = stack.method_7909();
        if (item instanceof class_1831) return true;
        if (item instanceof class_1829) return true;
        if (item instanceof class_1753) return true;
        if (item instanceof class_1764) return true;
        if (item instanceof class_1835) return true;
        if (item instanceof class_1819) return true;
        if (item instanceof class_1787) return true;
        if (item instanceof class_1786) return true;
        if (item instanceof class_1820) return true;
        if (item instanceof class_1738) return true;
        if (item == class_1802.field_8833) return true;
        if (item == class_1802.field_8288) return true;
        return false;
    }

    private static int getCategoryOrder(class_1799 stack) {
        class_1792 item = stack.method_7909();
        if (item instanceof class_1829) return 0;
        if (item instanceof class_1831) return 1;
        if (item instanceof class_1753 || item instanceof class_1764 || item instanceof class_1835) return 2;
        if (item instanceof class_1738) return 3;
        if (item == class_1802.field_8833) return 4;
        if (item == class_1802.field_8288 || item instanceof class_1819) return 5;
        if (item.method_57347().method_57832(net.minecraft.class_9334.field_50075)) return 6;
        if (item instanceof class_1747) return 7;
        return 8;
    }
}
