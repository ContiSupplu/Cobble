package com.cobble.dynamicisland;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * In-game browser screen using MCEF (com.cinemamod.mcef).
 * This Screen handles INPUT only — the actual browser texture is rendered
 * by DynamicIslandHud inside the DI panel.
 *
 * Two modes:
 *   1. MEDIA   — Locked to YouTube/Twitch, videos play natively in Chromium
 *                 Background playback: browser stays alive when ESC is pressed
 *   2. GENERAL — Full browser with content filtering
 */
public class InGameBrowser extends class_437 {

    public enum Mode { MEDIA, GENERAL }

    // ── Static browser state (shared with DynamicIslandHud for rendering) ──
    public static Object activeBrowser;    // MCEFBrowser instance
    public static Object activeRenderer;   // MCEFRenderer instance
    public static boolean isActive = false;
    public static boolean isMcefAvailable = false;
    public static boolean isMcefInitialized = false;
    public static Mode activeMode = Mode.MEDIA;
    public static String activeTab = "youtube"; // "youtube" or "twitch"
    public static String statusMessage = null;
    public static String blockedMessage = null;
    public static long blockedMessageUntil = 0;
    public static boolean backgroundPlayback = false; // browser alive but screen closed
    public static String pageTitle = ""; // current page title for background pill

    // Panel position (set by DynamicIslandHud each frame)
    public static int panelX, panelY, panelW, panelH;
    // Browser area inside the panel (with padding for tabs)
    public static int browserX, browserY, browserW, browserH;

    private static final String YOUTUBE_URL = "https://m.youtube.com";
    private static final String TWITCH_URL = "https://m.twitch.tv";

    // URL change detection
    private static String lastPolledUrl = "";
    private int pollTicks = 0;

    private final Mode mode;

    public InGameBrowser(Mode mode) {
        super(class_2561.method_43470(mode == Mode.MEDIA ? "Media Browser" : "Browser"));
        this.mode = mode;
        activeMode = mode;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        if (isActive && activeBrowser != null) {
            // Browser already open, just resize
            resizeBrowser();
            return;
        }

        activeTab = "youtube";
        lastPolledUrl = "";
        String url = mode == Mode.MEDIA ? YOUTUBE_URL : "https://www.google.com";

        try {
            Class<?> mcefClass = Class.forName("com.cinemamod.mcef.MCEF");
            isMcefAvailable = true;

            java.lang.reflect.Method isInitialized = mcefClass.getMethod("isInitialized");
            isMcefInitialized = (boolean) isInitialized.invoke(null);

            if (!isMcefInitialized) {
                statusMessage = "MCEF is downloading browser libraries...";
                isActive = true;
                return; // Will retry in tick()
            }

            createBrowser(url);
        } catch (ClassNotFoundException e) {
            statusMessage = "MCEF mod is required for the browser";
            isMcefAvailable = false;
            isActive = true;
        } catch (Exception e) {
            statusMessage = "Browser init failed: " + e.getMessage();
            isActive = true;
        }
    }

    private static void createBrowser(String url) {
        try {
            Class<?> mcefClass = Class.forName("com.cinemamod.mcef.MCEF");
            java.lang.reflect.Method createBrowser = mcefClass.getMethod("createBrowser", String.class, boolean.class);
            activeBrowser = createBrowser.invoke(null, url, true);

            java.lang.reflect.Method getRenderer = activeBrowser.getClass().getMethod("getRenderer");
            activeRenderer = getRenderer.invoke(activeBrowser);

            isActive = true;
            isMcefInitialized = true;
            statusMessage = null;

            // Initial resize
            resizeBrowser();
            System.out.println("[Browser] Created: " + url);
        } catch (Exception e) {
            statusMessage = "Browser creation failed";
            System.out.println("[Browser] createBrowser failed: " + e.getMessage());
        }
    }

    public static void resizeBrowser() {
        if (activeBrowser == null) return;
        try {
            int scaleFactor = (int) class_310.method_1551().method_22683().method_4495();
            int w = Math.max(browserW * scaleFactor, 100);
            int h = Math.max(browserH * scaleFactor, 100);
            java.lang.reflect.Method resize = activeBrowser.getClass().getMethod("resize", int.class, int.class);
            resize.invoke(activeBrowser, w, h);
        } catch (Exception ignored) {}
    }

    // ── Rendering is handled by DynamicIslandHud ──
    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {}

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Pass mouse position to HUD for hover detection
        DynamicIslandHud.mouseX = mouseX;
        DynamicIslandHud.mouseY = mouseY;
    }

    // ── Input Forwarding ──────────────────────────────

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Tab clicks are handled by DynamicIslandHud via TwitchScreen click system
        // Forward clicks in browser area to MCEF
        if (activeBrowser != null && isInBrowserArea(mouseX, mouseY)) {
            try {
                int bx = scaledX(mouseX);
                int by = scaledY(mouseY);
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendMousePress", int.class, int.class, int.class);
                m.invoke(activeBrowser, bx, by, button);
            } catch (Exception ignored) {}
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (activeBrowser != null) {
            try {
                int bx = scaledX(mouseX);
                int by = scaledY(mouseY);
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendMouseRelease", int.class, int.class, int.class);
                m.invoke(activeBrowser, bx, by, button);
            } catch (Exception ignored) {}
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (activeBrowser != null) {
            try {
                int bx = scaledX(mouseX);
                int by = scaledY(mouseY);
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendMouseMove", int.class, int.class);
                m.invoke(activeBrowser, bx, by);
            } catch (Exception ignored) {}
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        if (activeBrowser != null && isInBrowserArea(mouseX, mouseY)) {
            try {
                int bx = scaledX(mouseX);
                int by = scaledY(mouseY);
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendMouseWheel", int.class, int.class, double.class, int.class);
                m.invoke(activeBrowser, bx, by, vAmount, 0);
            } catch (Exception ignored) {}
            return true;
        }
        return super.method_25401(mouseX, mouseY, hAmount, vAmount);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            method_25419();
            return true;
        }
        if (activeBrowser != null) {
            try {
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendKeyPress", int.class, long.class, int.class);
                m.invoke(activeBrowser, keyCode, (long) scanCode, modifiers);
            } catch (Exception ignored) {}
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        if (activeBrowser != null) {
            try {
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendKeyRelease", int.class, long.class, int.class);
                m.invoke(activeBrowser, keyCode, (long) scanCode, modifiers);
            } catch (Exception ignored) {}
        }
        return super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        if (activeBrowser != null) {
            try {
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("sendKeyTyped", char.class, int.class);
                m.invoke(activeBrowser, chr, modifiers);
            } catch (Exception ignored) {}
            return true;
        }
        return super.method_25400(chr, modifiers);
    }

    // ── Coordinate Helpers ────────────────────────────

    private int scaledX(double mouseX) {
        int scaleFactor = (int) class_310.method_1551().method_22683().method_4495();
        return (int) ((mouseX - browserX) * scaleFactor);
    }

    private int scaledY(double mouseY) {
        int scaleFactor = (int) class_310.method_1551().method_22683().method_4495();
        return (int) ((mouseY - browserY) * scaleFactor);
    }

    private boolean isInBrowserArea(double mx, double my) {
        return mx >= browserX && mx < browserX + browserW && my >= browserY && my < browserY + browserH;
    }

    // ── Navigation ────────────────────────────────────

    public static void switchTab(String tab) {
        if (tab.equals(activeTab)) return;
        activeTab = tab;
        loadUrl("youtube".equals(tab) ? YOUTUBE_URL : TWITCH_URL);
    }

    public static void loadUrl(String url) {
        if (activeMode == Mode.GENERAL && ContentFilter.isBlocked(url)) {
            blockedMessage = ContentFilter.getBlockReason(url);
            blockedMessageUntil = System.currentTimeMillis() + 3000;
            return;
        }
        if (activeBrowser != null) {
            try {
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("loadURL", String.class);
                m.invoke(activeBrowser, url);
            } catch (Exception ignored) {}
        }
    }

    /** Get browser texture ID (called by DynamicIslandHud) */
    public static int getTextureID() {
        if (activeRenderer == null) return 0;
        try {
            java.lang.reflect.Method m = activeRenderer.getClass().getMethod("getTextureID");
            return (int) m.invoke(activeRenderer);
        } catch (Exception e) {
            return 0;
        }
    }

    /** Get current browser URL */
    public static String getCurrentUrl() {
        if (activeBrowser == null) return "";
        try {
            java.lang.reflect.Method m = activeBrowser.getClass().getMethod("getURL");
            return (String) m.invoke(activeBrowser);
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public void method_25393() {
        super.method_25393();

        // If MCEF was downloading, check if ready now
        if (isMcefAvailable && !isMcefInitialized) {
            try {
                Class<?> mcefClass = Class.forName("com.cinemamod.mcef.MCEF");
                java.lang.reflect.Method isInit = mcefClass.getMethod("isInitialized");
                isMcefInitialized = (boolean) isInit.invoke(null);
                if (isMcefInitialized && activeBrowser == null) {
                    String url = activeMode == Mode.MEDIA ? YOUTUBE_URL : "https://www.google.com";
                    createBrowser(url);
                }
            } catch (Exception ignored) {}
        }

        // Poll for content filtering (general mode only)
        pollTicks++;
        if (activeBrowser != null && pollTicks % 10 == 0) {
            String currentUrl = getCurrentUrl();
            if (currentUrl != null && !currentUrl.equals(lastPolledUrl)) {
                lastPolledUrl = currentUrl;

                // Update page title for background pill
                pageTitle = getPageTitle();

                // General mode: content filter
                if (activeMode == Mode.GENERAL && ContentFilter.isBlocked(currentUrl)) {
                    blockedMessage = ContentFilter.getBlockReason(currentUrl);
                    blockedMessageUntil = System.currentTimeMillis() + 3000;
                    loadUrl("https://www.google.com");
                }
            }
        }
    }

    @Override
    public void method_25419() {
        if (activeMode == Mode.MEDIA && activeBrowser != null) {
            // Media mode: keep browser alive for background audio playback
            backgroundPlayback = true;
            System.out.println("[Browser] Minimized to background (audio continues)");
        } else {
            // General mode: fully close browser
            destroyBrowser();
        }
        DynamicIslandMod.isMediaOpen = false;
        super.method_25419();
    }

    /** Fully destroy the browser instance */
    public static void destroyBrowser() {
        if (activeBrowser != null) {
            try {
                java.lang.reflect.Method m = activeBrowser.getClass().getMethod("close");
                m.invoke(activeBrowser);
            } catch (Exception ignored) {}
            activeBrowser = null;
            activeRenderer = null;
        }
        isActive = false;
        backgroundPlayback = false;
        statusMessage = null;
        pageTitle = "";
    }

    /** Is a browser playing in the background? */
    public static boolean isPlayingInBackground() {
        return backgroundPlayback && activeBrowser != null;
    }

    /** Get page title from the browser */
    public static String getPageTitle() {
        if (activeBrowser == null) return "";
        try {
            // CefBrowser has getTitle() method
            java.lang.reflect.Method m = activeBrowser.getClass().getMethod("getTitle");
            String title = (String) m.invoke(activeBrowser);
            return title != null ? title : "";
        } catch (Exception e) {
            return "";
        }
    }

    /** Stop background playback and close browser */
    public static void stopBackground() {
        destroyBrowser();
    }

    @Override
    public boolean method_25421() { return false; }

    /** Open media browser (or resume if playing in background) */
    public static void openMedia() {
        class_310.method_1551().execute(() -> {
            if (backgroundPlayback && activeBrowser != null) {
                // Resume — reopen the same browser
                backgroundPlayback = false;
                DynamicIslandMod.isMediaOpen = true;
                class_310.method_1551().method_1507(new InGameBrowser(Mode.MEDIA));
            } else {
                class_310.method_1551().method_1507(new InGameBrowser(Mode.MEDIA));
            }
        });
    }

    /** Open general browser */
    public static void openGeneral() {
        class_310.method_1551().execute(() ->
            class_310.method_1551().method_1507(new InGameBrowser(Mode.GENERAL)));
    }
}
