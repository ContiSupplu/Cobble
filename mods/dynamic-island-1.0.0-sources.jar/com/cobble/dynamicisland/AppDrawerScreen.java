package com.cobble.dynamicisland;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class AppDrawerScreen extends class_437 {
    // Store click coordinates for the HUD to consume
    public static int clickX = -1, clickY = -1;
    public static boolean clickPending = false;
    public static double scrollDelta = 0;

    public AppDrawerScreen() {
        super(class_2561.method_43470("App Drawer"));
    }

    @Override
    public boolean method_25421() { return false; }

    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {}

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Store mouse position for HUD hover detection
        DynamicIslandHud.mouseX = mouseX;
        DynamicIslandHud.mouseY = mouseY;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            clickX = (int) mouseX;
            clickY = (int) mouseY;
            clickPending = true;
        }
        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        scrollDelta += vAmount;
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE || keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_X) {
            DynamicIslandHud.isAppDrawerOpen = false;
            DynamicIslandMod.isAppDrawerOpen = false;
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
