package com.cobble.dynamicisland;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Content filter for the in-game general browser.
 * Blocks adult content, dark web, malware, violence/extremism, and hacking sites.
 */
public class ContentFilter {

    /** Check if a URL should be blocked */
    public static boolean isBlocked(String url) {
        if (url == null || url.isEmpty()) return false;
        String lower = url.toLowerCase();

        // Extract domain from URL
        String domain = extractDomain(lower);
        if (domain.isEmpty()) return false;

        // Block .onion (dark web)
        if (domain.endsWith(".onion")) return true;

        // Block known bad domains
        if (BLOCKED_DOMAINS.contains(domain)) return true;

        // Check parent domains (e.g., "sub.badsite.com" → check "badsite.com")
        String[] parts = domain.split("\\.");
        for (int i = 1; i < parts.length - 1; i++) {
            String parent = String.join(".", Arrays.copyOfRange(parts, i, parts.length));
            if (BLOCKED_DOMAINS.contains(parent)) return true;
        }

        // Pattern-based blocking
        for (Pattern pattern : BLOCKED_PATTERNS) {
            if (pattern.matcher(domain).find()) return true;
        }

        // Block certain URL paths
        for (String keyword : BLOCKED_PATH_KEYWORDS) {
            if (lower.contains(keyword)) return true;
        }

        return false;
    }

    /** Get a user-friendly block reason */
    public static String getBlockReason(String url) {
        if (url == null) return "Blocked";
        String lower = url.toLowerCase();
        String domain = extractDomain(lower);

        if (domain.endsWith(".onion")) return "Dark web access is blocked";
        // Generic reason to avoid revealing filter specifics
        return "This site has been blocked by content filter";
    }

    private static String extractDomain(String url) {
        try {
            String s = url;
            // Remove protocol
            int idx = s.indexOf("://");
            if (idx >= 0) s = s.substring(idx + 3);
            // Remove path
            idx = s.indexOf('/');
            if (idx >= 0) s = s.substring(0, idx);
            // Remove port
            idx = s.indexOf(':');
            if (idx >= 0) s = s.substring(0, idx);
            // Remove www prefix for matching
            if (s.startsWith("www.")) s = s.substring(4);
            return s;
        } catch (Exception e) {
            return "";
        }
    }

    // ── Domain Blocklist ──────────────────────────────
    // Comprehensive list of blocked domains by category

    private static final Set<String> BLOCKED_DOMAINS = new HashSet<>(Arrays.asList(
        // ─── Adult Content ───
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com",
        "redtube.com", "youporn.com", "tube8.com", "spankbang.com",
        "chaturbate.com", "stripchat.com", "bongacams.com", "livejasmin.com",
        "cam4.com", "myfreecams.com", "camsoda.com", "flirt4free.com",
        "brazzers.com", "bangbros.com", "realitykings.com", "naughtyamerica.com",
        "mofos.com", "digitalplayground.com", "wicked.com", "adulttime.com",
        "onlyfans.com", "fansly.com", "manyvids.com", "clips4sale.com",
        "porntrex.com", "eporner.com", "tnaflix.com", "drtuber.com",
        "txxx.com", "hclips.com", "pornone.com", "fuq.com",
        "beeg.com", "ixxx.com", "4tube.com", "sunporno.com",
        "porn.com", "sex.com", "xxx.com", "adult.com",
        "hentaihaven.xxx", "nhentai.net", "hanime.tv", "hentai.tv",
        "rule34.xxx", "rule34.paheal.net", "e621.net", "gelbooru.com",
        "danbooru.donmai.us", "sankakucomplex.com",
        "literotica.com", "asstr.org", "sexstories.com",
        "motherless.com", "heavy-r.com", "efukt.com",
        "omegle.com", "chatroulette.com",
        "backpage.com", "bedpage.com", "skipthegames.com",
        "ashleymadison.com", "adultfriendfinder.com",

        // ─── Malware / Phishing ───
        "malware-traffic-analysis.net",

        // ─── Extremism / Violence ───
        "stormfront.org", "dailystormer.name", "8kun.top",
        "4chan.org", "8chan.se", "kiwifarms.net",
        "thepiratebay.org", "1337x.to", "rarbg.to",

        // ─── Hacking / Exploit Sites ───
        "hackforums.net", "raidforums.com", "cracked.io",
        "nulled.to", "leakbase.io", "breachforums.is",
        "exploit-db.com", "0day.today",

        // ─── Dark Web Mirrors ───
        "darknetlive.com", "dark.fail",

        // ─── Illegal Marketplaces ───
        "silkroad.com",

        // ─── Gambling (underage protection) ───
        "stake.com", "roobet.com", "csgoroll.com",
        "gamdom.com", "rollbit.com"
    ));

    // Pattern-based blocking for domains containing these terms
    private static final Pattern[] BLOCKED_PATTERNS = new Pattern[] {
        Pattern.compile("\\bporn\\b"),
        Pattern.compile("\\bxxx\\b"),
        Pattern.compile("\\badult\\b"),
        Pattern.compile("\\bhentai\\b"),
        Pattern.compile("\\bnude[sz]?\\b"),
        Pattern.compile("\\bnaked\\b"),
        Pattern.compile("\\bescort[sz]?\\b"),
        Pattern.compile("\\bstrip(club)?\\b"),
        Pattern.compile("\\bcam(girl|boy|model)\\b"),
        Pattern.compile("\\b(dark|deep)web\\b"),
        Pattern.compile("\\bhack(ing|er|tool)\\b"),
        Pattern.compile("\\bexploit\\b"),
        Pattern.compile("\\bphish(ing)?\\b"),
        Pattern.compile("\\bmalware\\b"),
        Pattern.compile("\\bransom(ware)?\\b"),
        Pattern.compile("\\.onion$"),
    };

    // Block URLs containing these path keywords
    private static final String[] BLOCKED_PATH_KEYWORDS = new String[] {
        "/nsfw", "/adult", "/xxx", "/porn",
    };
}
