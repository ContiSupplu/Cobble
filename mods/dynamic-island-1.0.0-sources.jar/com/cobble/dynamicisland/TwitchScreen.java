package com.cobble.dynamicisland;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Transparent screen for the media viewer panel.
 * Mouse-first design — all controls are clickable via cursor.
 *
 * Keyboard only used for:
 *   - Typing in search box
 *   - Enter to submit search
 *   - ESC to close (without stopping playback)
 *
 * Mouse events forwarded to DynamicIslandHud for:
 *   - Clicking search results, tabs, pagination
 *   - Play/pause, seek, volume, back button
 *   - Progress bar scrubbing
 */
public class TwitchScreen extends class_437 {

    private class_342 inputField;

    // Click state for HUD consumption
    public static int clickX = -1, clickY = -1;
    public static boolean clickPending = false;
    public static double scrollDelta = 0;

    // Drag state for progress bar scrubbing
    public static boolean isDragging = false;
    public static int dragX = -1, dragY = -1;

    public TwitchScreen() {
        super(class_2561.method_43470("Media Viewer"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        // Invisible input field — captures keystrokes for search
        int fieldW = 250;
        int fieldX = this.field_22789 / 2 - fieldW / 2;
        int fieldY = this.field_22790; // offscreen — HUD renders the visual

        this.inputField = new class_342(
                this.field_22793, fieldX, fieldY, fieldW, 12,
                class_2561.method_43470("")
        );
        this.inputField.method_1880(500);
        this.inputField.method_1858(false);
        this.inputField.method_1868(0xEEEEEE);
        this.method_37063(this.inputField);
        this.method_48265(this.inputField);

        // Restore in-progress text
        if ("SEARCH".equals(MediaViewer.activeTab)) {
            this.inputField.method_1852(MediaViewer.searchQuery);
        } else if (MediaViewer.mediaType == MediaViewer.MediaType.TWITCH) {
            this.inputField.method_1852(TwitchChat.inputText);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        boolean isSearchTab = "SEARCH".equals(MediaViewer.activeTab);

        // ESC — close panel WITHOUT stopping playback
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            DynamicIslandMod.isMediaOpen = false;
            // Don't call MediaViewer.closeStream() — video keeps playing in background
            this.method_25419();
            return true;
        }

        // T key does NOT close — only ESC closes. This lets users type 't' in search.

        // Search mode — Enter to search or select
        if (isSearchTab) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                String query = this.inputField.method_1882().trim();
                if (!query.isEmpty()) {
                    MediaViewer.sendSearch(query, MediaViewer.searchSource);
                }
                return true;
            }
            // Let text field handle typing
            boolean result = super.method_25404(keyCode, scanCode, modifiers);
            MediaViewer.searchQuery = this.inputField.method_1882();
            return result;
        }

        // Twitch chat — Enter to send
        if (MediaViewer.mediaType == MediaViewer.MediaType.TWITCH && !isSearchTab) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                String msg = this.inputField.method_1882().trim();
                if (!msg.isEmpty()) {
                    TwitchChat.sendMessage(msg);
                    this.inputField.method_1852("");
                    TwitchChat.inputText = "";
                }
                return true;
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        boolean isSearchTab = "SEARCH".equals(MediaViewer.activeTab);
        if (isSearchTab || MediaViewer.mediaType == MediaViewer.MediaType.TWITCH) {
            boolean result = super.method_25400(chr, modifiers);
            if (isSearchTab) {
                MediaViewer.searchQuery = this.inputField.method_1882();
            } else {
                TwitchChat.inputText = this.inputField.method_1882();
            }
            return result;
        }
        return super.method_25400(chr, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        boolean isSearchTab = "SEARCH".equals(MediaViewer.activeTab);
        if (isSearchTab || MediaViewer.mediaType == MediaViewer.MediaType.TWITCH) {
            boolean result = super.method_16803(keyCode, scanCode, modifiers);
            if (isSearchTab) {
                MediaViewer.searchQuery = this.inputField.method_1882();
            } else {
                TwitchChat.inputText = this.inputField.method_1882();
            }
            return result;
        }
        return super.method_16803(keyCode, scanCode, modifiers);
    }

    // ── Mouse Events — forwarded to HUD for click detection ──

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            clickX = (int) mouseX;
            clickY = (int) mouseY;
            clickPending = true;
        }
        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0) {
            isDragging = true;
            dragX = (int) mouseX;
            dragY = (int) mouseY;
        }
        return true;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        isDragging = false;
        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollDelta += verticalAmount;
        return true;
    }

    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Fully transparent — game stays visible
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Forward mouse position to HUD for hover detection
        DynamicIslandHud.mouseX = mouseX;
        DynamicIslandHud.mouseY = mouseY;
    }

    @Override
    public boolean method_25421() { return false; }
}
