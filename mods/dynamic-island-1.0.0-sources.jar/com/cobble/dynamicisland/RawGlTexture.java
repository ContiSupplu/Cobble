package com.cobble.dynamicisland;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1044;
import net.minecraft.class_3300;

/**
 * Wraps a raw OpenGL texture ID (from WATERMeDIA's VideoPlayer.texture())
 * so it can be used with Minecraft's DrawContext.drawTexture() API.
 *
 * DrawContext.drawTexture internally calls getGlId() to bind the texture,
 * so by overriding that we can render WATERMeDIA's video frames.
 */
public class RawGlTexture extends class_1044 {

    private int field_5204 = 0;
    private int width = 1;
    private int height = 1;

    /**
     * Update the GL texture ID each frame (WATERMeDIA may recreate it).
     */
    public void setGlId(int id) {
        this.field_5204 = id;
    }

    public void setDimensions(int w, int h) {
        if (w > 0) this.width = w;
        if (h > 0) this.height = h;
    }

    public int getFrameWidth() { return width; }
    public int getFrameHeight() { return height; }

    @Override
    public int method_4624() {
        return field_5204;
    }

    @Override
    public void method_4625(class_3300 manager) {
        // No-op: texture data comes from WATERMeDIA/VLC
    }

    @Override
    public void close() {
        // Don't delete the GL texture — WATERMeDIA owns it
        this.field_5204 = 0;
    }
}
