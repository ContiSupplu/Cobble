package com.cobble.dynamicisland;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1799;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class DynamicIslandHud implements HudRenderCallback {

    private float currentWidth = 100f;
    private float currentHeight = 26f;
    private float currentY = -34f;
    private float shimmerPhase = 0f;
    private float expandProgress = 0f;
    private float pebbleProgress = 0f;
    private float notifCenterProgress = 0f;
    private float settingsProgress = 0f;
    private float combatProgress = 0f;
    private float mediaProgress = 0f;

    // App Drawer state
    public static boolean isAppDrawerOpen = false;
    public static float appDrawerProgress = 0f;
    public static int mouseX = 0, mouseY = 0;

    // Coord copy/share feedback
    private String coordFeedback = null;
    private long coordFeedbackUntil = 0;

    private String currentAlbumUrl = null;
    private class_2960 albumTextureId = null;
    private boolean albumLoading = false;
    private int albumTintColor = 0x0A0A0A;
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private float serverProgress = 0f;
    private long serverUpdateTime = 0;
    private long serverDuration = 0;
    private boolean serverPlaying = false;
    private float displayProgress = 0f;
    private float lyricsScrollOffset = 0f;
    private int lastLyricsIndex = -1;

    @Override
    public void onHudRender(class_332 ctx, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842 || client.field_1724 == null) return;

        class_327 font = client.field_1772;
        int screenW = client.method_22683().method_4486();

        LauncherState state = DynamicIslandMod.currentState;
        boolean hasNotif = DynamicIslandMod.hasNotification();
        float notifAlpha = DynamicIslandMod.getNotificationAlpha();
        boolean isExpanded = DynamicIslandMod.isExpanded;

        float expandTarget = (isExpanded && state != null && state.spotify != null && state.spotify.playing) ? 1f : 0f;
        expandProgress += (expandTarget - expandProgress) * 0.12f;
        if (expandProgress < 0.01f) expandProgress = 0f;
        if (expandProgress > 0.99f) expandProgress = 1f;

        // ── Determine content ──────────────────────
        float targetW = 100f;
        float targetH = 26f;
        float targetY = 4f;

        String line1 = "";
        String line2 = "";
        String center = "";
        boolean showMusic = false;
        boolean musicPlaying = false;
        boolean showDeath = false;
        boolean showBiome = GameAlerts.hasBiomeSubtitle();
        boolean showCombat = false;
        boolean showWaypoint = false;
        float progress = 0f;
        boolean isAlert = false;

        boolean hasMusic = state != null && state.spotify != null && (state.spotify.playing || state.spotify.title != null);
        boolean deathWantsDeath = GameAlerts.persistentText != null && "death".equals(GameAlerts.persistentType);
        boolean songPeek = GameAlerts.isSongPeekActive() && hasMusic;
        boolean nonDeathPersistent = GameAlerts.persistentText != null && !"death".equals(GameAlerts.persistentType);
        boolean combatActive = CombatTracker.isInCombat();
        boolean waypointActive = WaypointManager.activeWaypoint != null;

        // Combat-relevant alert types (shine through combat HUD)
        boolean isCombatRelevantAlert = nonDeathPersistent && (
            "elytra".equals(GameAlerts.persistentType) ||
            "effect".equals(GameAlerts.persistentType) ||
            "durability".equals(GameAlerts.persistentType)
        );

        // Clear displayed coords
        DynamicIslandMod.displayedCoords = null;

        // Priority: combat-relevant alerts > combat HUD > notification > waypoint > persistent > death > music > idle
        if (combatActive && isCombatRelevantAlert) {
            // Combat-relevant alerts shine through
            center = GameAlerts.persistentText;
            isAlert = GameAlerts.persistentIsAlert;
            targetW = Math.max(160, font.method_1727(center) + 28);
            targetH = 26f;
        } else if (combatActive) {
            // Combat HUD
            showCombat = true;
            // Auto-close media panel when entering combat (audio keeps playing)
            if (DynamicIslandMod.isMediaOpen) {
                DynamicIslandMod.isMediaOpen = false;
                if (class_310.method_1551().field_1755 instanceof TwitchScreen) {
                    class_310.method_1551().method_1507(null);
                }
            }
            if (CombatTracker.isCelebrating()) {
                String killText = "✦ Eliminated " + CombatTracker.killedPlayerName;
                targetW = Math.max(160, font.method_1727(killText) + 32);
                targetH = 30f;
            } else {
                String oppName = CombatTracker.opponentName != null ? CombatTracker.opponentName : "Unknown";
                int nameW = font.method_1727(oppName);
                String hpStr = (int)CombatTracker.opponentHealth + "/" + (int)CombatTracker.opponentMaxHealth;
                int hpW = font.method_1727(hpStr);
                // Width = head(22) + max(name+hp, hearts, equipment) + padding
                int heartsW = Math.max(1, (int)(CombatTracker.opponentMaxHealth / 2)) * font.method_1727("\u2764");
                int equipW = 4 * 14 + 6 + 2 * 14; // 4 armor + divider + weapon/offhand
                int contentW = Math.max(nameW + hpW + 12, Math.max(heartsW, equipW));
                targetW = 22 + contentW + 12;
                targetH = !CombatTracker.opponentEffects.isEmpty() ? 68f : 56f;
            }
        } else if (hasNotif) {
            center = DynamicIslandMod.currentNotification;
            targetW = Math.max(150, font.method_1727(center) + 28);
            targetH = 26f;
            isAlert = center.contains("Health") || center.contains("Hunger");
        } else if (waypointActive) {
            showWaypoint = true;
            WaypointManager.Waypoint wp = WaypointManager.activeWaypoint;
            int px = (int) client.field_1724.method_23317();
            int pz = (int) client.field_1724.method_23321();
            float yaw = client.field_1724.method_36454();
            int dist = (int) WaypointManager.getDistance(px, pz);
            String dir = WaypointManager.getRelativeDirection(px, pz, yaw);
            center = dist + " blocks · " + dir;
            String wpCoords = wp.x + " " + wp.y + " " + wp.z;
            targetW = Math.max(180, Math.max(font.method_1727(center), font.method_1727(wpCoords)) + 32);
            targetH = 40f;
            DynamicIslandMod.displayedCoords = wpCoords;
        } else if (TimerManager.hasFinishedTimer()) {
            // Timer just finished — persistent until dismissed
            center = "⏱ " + TimerManager.finishedTimerName + " finished!";
            targetW = Math.max(180, font.method_1727(center) + 32);
            targetH = 40f;
        } else if (TimerManager.isInCountdown()) {
            // Last 10 seconds of a timer — live countdown
            long remaining = TimerManager.getRemaining(TimerManager.countdownTimer);
            center = "⏱ " + TimerManager.countdownTimer.name;
            targetW = Math.max(150, font.method_1727(center) + 32);
            targetH = 34f;
        } else if (nonDeathPersistent) {
            center = GameAlerts.persistentText;
            isAlert = GameAlerts.persistentIsAlert;
            targetW = Math.max(160, font.method_1727(center) + 28);
            targetH = 26f;
        } else if (deathWantsDeath && !songPeek) {
            showDeath = true;
            center = GameAlerts.persistentText;
            String coords = GameAlerts.getDeathCoords();
            targetW = Math.max(180, Math.max(font.method_1727(center), font.method_1727(coords)) + 32);
            targetH = 40f;
            DynamicIslandMod.displayedCoords = coords;
        } else if (hasMusic) {
            showMusic = true;
            musicPlaying = state.spotify.playing;
            line1 = state.spotify.title != null ? state.spotify.title : "";
            line2 = state.spotify.artist != null ? state.spotify.artist : "";

            if (state.spotify.progress != serverProgress || state.spotify.duration != serverDuration) {
                serverProgress = state.spotify.progress;
                serverDuration = state.spotify.duration;
                serverUpdateTime = System.currentTimeMillis();
                serverPlaying = state.spotify.playing;
            }

            if (serverPlaying && serverDuration > 0) {
                long elapsed = System.currentTimeMillis() - serverUpdateTime;
                progress = serverProgress + (float) elapsed / serverDuration;
                progress = Math.min(1f, progress);
            } else {
                progress = serverProgress;
            }

            int maxTextW = 140;
            if (font.method_1727(line1) > maxTextW) {
                while (font.method_1727(line1 + "...") > maxTextW && line1.length() > 0)
                    line1 = line1.substring(0, line1.length() - 1);
                line1 += "...";
            }
            if (font.method_1727(line2) > maxTextW) {
                while (font.method_1727(line2 + "...") > maxTextW && line2.length() > 0)
                    line2 = line2.substring(0, line2.length() - 1);
                line2 += "...";
            }

            int textW = Math.max(font.method_1727(line1), font.method_1727(line2));
            targetW = Math.max(170, 5 + 22 + 6 + textW + 6 + 18 + 6);
            targetH = 34f;

            if (expandProgress > 0.01f) targetH += 22f * expandProgress;

            // Lyrics mode: expand for 3 lines of lyrics
            boolean hasLyrics = DynamicIslandMod.isLyricsMode && state.spotify.lyrics != null && state.spotify.lyrics.length > 0;
            if (hasLyrics) {
                targetH = 120f;
                targetW = Math.max(targetW, 240f);
            }

            if (state.spotify.albumArt != null && !state.spotify.albumArt.equals(currentAlbumUrl)) {
                loadAlbumArt(state.spotify.albumArt);
            }
        } else if (state != null && state.time != null) {
            int px = (int) client.field_1724.method_23317();
            int py = (int) client.field_1724.method_23318();
            int pz = (int) client.field_1724.method_23321();
            String mcTime = GameAlerts.getMcTimeDisplay();
            if (mcTime != null) {
                center = state.time + "  §7|§r  " + mcTime + "  §7|§r  " + px + " " + py + " " + pz;
            } else {
                center = state.time + "  §7|§r  " + px + " " + py + " " + pz;
            }
            targetW = Math.max(140, font.method_1727(center) + 32);
            targetH = 26f;
            DynamicIslandMod.displayedCoords = px + " " + py + " " + pz;
        }

        // Coord feedback display
        if (coordFeedback != null && System.currentTimeMillis() > coordFeedbackUntil) {
            coordFeedback = null;
        }

        // Biome footnote expands pill slightly
        if (showBiome && !hasNotif && !showCombat && !DynamicIslandMod.isPebbleOpen && !DynamicIslandMod.isNotifCenterOpen && !DynamicIslandMod.isSettingsOpen && !DynamicIslandMod.isMediaOpen) targetH += 12f;

        // Panel overrides — unique sizes per panel
        boolean pebbleOpen = DynamicIslandMod.isPebbleOpen;
        boolean notifOpen = DynamicIslandMod.isNotifCenterOpen;
        boolean settingsOpen = DynamicIslandMod.isSettingsOpen;
        boolean mediaOpen = DynamicIslandMod.isMediaOpen;
        boolean drawerOpen = isAppDrawerOpen;
        if (pebbleOpen) { targetW = 280f; targetH = 200f; }
        if (notifOpen) { targetW = 260f; targetH = 220f; }
        if (settingsOpen) { targetW = 300f; targetH = 260f; }
        if (mediaOpen) {
            if (InGameBrowser.isActive) {
                // Browser mode — large panel for embedded Chromium
                targetW = Math.min(screenW - 20, 420f);
                targetH = Math.min(client.method_22683().method_4502() - 20, 320f);
            } else {
                boolean isPlaying = !"SEARCH".equals(MediaViewer.activeTab);
                if (isPlaying) { targetW = 360f; targetH = 260f; }
                else {
                    int resultCount = MediaViewer.searchResults.isEmpty() ? 0 : MediaViewer.getPageResults().size();
                    if (resultCount == 0 && !MediaViewer.isSearching) {
                        targetW = 300f; targetH = 50f;
                    } else if (resultCount == 0 && MediaViewer.isSearching) {
                        targetW = 300f; targetH = 70f;
                    } else {
                        targetW = 350f;
                        targetH = Math.min(40 + resultCount * 36 + 30, 300f);
                    }
                }
            }
        }
        if (drawerOpen) { targetW = 220f; targetH = 220f; } // 3x3 grid with Browser
        // Background media playback — wider pill to show title + EQ bars
        if (!mediaOpen && !pebbleOpen && !notifOpen && !settingsOpen && !drawerOpen && !showCombat) {
            if (MediaViewer.isPlayingInBackground()) {
                String bgTitle = MediaViewer.currentTitle;
                int titleW = font.method_1727(bgTitle);
                targetW = Math.max(220, Math.min(titleW + 60, 320));
                targetH = 34f;
            } else if (InGameBrowser.isPlayingInBackground()) {
                String bgTitle = InGameBrowser.pageTitle;
                if (bgTitle.isEmpty()) bgTitle = "Browser";
                int titleW = font.method_1727(bgTitle);
                targetW = Math.max(220, Math.min(titleW + 60, 320));
                targetH = 34f;
            }
        }

        // ── Animation ──────────────────────────────
        float lerp = 0.12f;
        currentWidth += (targetW - currentWidth) * lerp;
        currentHeight += (targetH - currentHeight) * lerp;
        currentY += (targetY - currentY) * lerp;
        displayProgress += (progress - displayProgress) * 0.15f;
        shimmerPhase += 0.015f;
        if (shimmerPhase > 2f) shimmerPhase -= 2f;

        // Panel open/close progress
        float pebbleTarget = pebbleOpen ? 1f : 0f;
        pebbleProgress += (pebbleTarget - pebbleProgress) * 0.1f;
        if (pebbleProgress < 0.005f) pebbleProgress = 0f;
        if (pebbleProgress > 0.995f) pebbleProgress = 1f;

        float ncTarget = notifOpen ? 1f : 0f;
        notifCenterProgress += (ncTarget - notifCenterProgress) * 0.1f;
        if (notifCenterProgress < 0.005f) notifCenterProgress = 0f;
        if (notifCenterProgress > 0.995f) notifCenterProgress = 1f;

        float stTarget = settingsOpen ? 1f : 0f;
        settingsProgress += (stTarget - settingsProgress) * 0.1f;
        if (settingsProgress < 0.005f) settingsProgress = 0f;
        if (settingsProgress > 0.995f) settingsProgress = 1f;

        float combatTarget = combatActive ? 1f : 0f;
        combatProgress += (combatTarget - combatProgress) * 0.12f;
        if (combatProgress < 0.005f) combatProgress = 0f;
        if (combatProgress > 0.995f) combatProgress = 1f;

        float mediaTarget = mediaOpen ? 1f : 0f;
        mediaProgress += (mediaTarget - mediaProgress) * 0.1f;
        if (mediaProgress < 0.005f) mediaProgress = 0f;
        if (mediaProgress > 0.995f) mediaProgress = 1f;

        float drawerTarget = drawerOpen ? 1f : 0f;
        appDrawerProgress += (drawerTarget - appDrawerProgress) * 0.12f;
        if (appDrawerProgress < 0.005f) appDrawerProgress = 0f;
        if (appDrawerProgress > 0.995f) appDrawerProgress = 1f;

        int x = (int)(screenW / 2f - currentWidth / 2f);
        int y = (int) currentY;
        int w = (int) currentWidth;
        int h = (int) currentHeight;
        if (w < 10 || h < 10) return;

        // ══════════════════════════════════════════════
        // PILL BACKGROUND
        // ══════════════════════════════════════════════

        int bgAlpha = showCombat ? 0xAA : (hasNotif ? (int)(0xEE * notifAlpha) : 0xEE);
        ThemeManager.Theme theme = ThemeManager.current();
        int bgColor;
        if (showCombat) bgColor = 0x1A0505;
        else if (isAlert) bgColor = 0x250505;
        else if (showDeath) bgColor = 0x180505;
        else if (showMusic && theme.useAlbumArt && albumTintColor != 0x0A0A0A) bgColor = albumTintColor;
        else if (showMusic && albumTintColor != 0x0A0A0A) bgColor = albumTintColor;
        else bgColor = theme.bgColor;

        int bg = (bgAlpha << 24) | bgColor;
        int radius = Math.min(h / 2, 16);
        drawRoundedRect(ctx, x, y, w, h, radius, bg);

        // Theme border glow
        if (theme.borderGlow != 0 && !showCombat) {
            drawRoundedRect(ctx, x - 1, y - 1, w + 2, h + 2, radius + 1, theme.borderGlow);
            drawRoundedRect(ctx, x, y, w, h, radius, bg); // redraw bg on top
        }
        // Combat border glow (red pulse)
        if (showCombat && combatProgress > 0.01f) {
            int pulseAlpha = (int)(0x40 * combatProgress * (0.6f + 0.4f * (float)Math.sin(System.currentTimeMillis() / 200.0)));
            pulseAlpha = Math.max(0, Math.min(0xFF, pulseAlpha));
            drawRoundedRect(ctx, x - 1, y - 1, w + 2, h + 2, radius + 1, (pulseAlpha << 24) | 0xFF3333);
            drawRoundedRect(ctx, x, y, w, h, radius, bg);
        }

        if (!hasNotif || notifAlpha > 0.5f) {
            ctx.method_25294(x + radius, y + 1, x + w - radius, y + 2, 0x0CFFFFFF);
        }

        float shimmerX = (shimmerPhase - 0.5f) * w * 2;
        int sL = x + Math.max(0, (int) shimmerX);
        int sR = x + Math.min(w, (int)(shimmerX + w * 0.3f));
        if (sL < sR && sL < x + w && sR > x) {
            sL = Math.max(sL, x + radius);
            sR = Math.min(sR, x + w - radius);
            if (sL < sR) ctx.method_25294(sL, y + 1, sR, y + h - 1, 0x06FFFFFF);
        }

        // ══════════════════════════════════════════════
        // CONTENT (hidden when Pebble is taking over)
        // ══════════════════════════════════════════════

      if (pebbleProgress < 0.3f && notifCenterProgress < 0.3f && settingsProgress < 0.3f && mediaProgress < 0.3f && appDrawerProgress < 0.3f) {

        if (hasNotif) {
            int textAlpha = (int)(0xDD * notifAlpha);
            int textColor = (textAlpha << 24) | 0xDDDDDD;
            int textY = y + (h - 7) / 2;

            // Player head for nearby player alerts
            if (GameAlerts.hasNotificationHead()) {
                int headSize = 14;
                int totalW = headSize + 4 + font.method_1727(center);
                int startX = screenW / 2 - totalW / 2;

                // Draw 8x8 face from skin texture (UV: 8,8 to 16,16 in 64x64 skin)
                ctx.method_25293(GameAlerts.notificationHeadTexture,
                    startX, y + (h - headSize) / 2,
                    headSize, headSize,
                    8f, 8f, 8, 8, 64, 64);
                // Draw hat overlay layer (UV: 40,8 to 48,16)
                ctx.method_25293(GameAlerts.notificationHeadTexture,
                    startX, y + (h - headSize) / 2,
                    headSize, headSize,
                    40f, 8f, 8, 8, 64, 64);

                ctx.method_25303(font, center, startX + headSize + 4, textY, textColor);
            } else {
                ctx.method_25303(font, center, screenW / 2 - font.method_1727(center) / 2, textY, textColor);
            }
        } else if (showCombat) {
            // ── COMBAT HUD ──

            if (CombatTracker.isCelebrating()) {
                // ── KILL CELEBRATION ──
                long elapsed = System.currentTimeMillis() - CombatTracker.killCelebrationTime;
                float celebAlpha = elapsed < 2500 ? 1.0f : 1.0f - ((elapsed - 2500) / 500f);
                celebAlpha = Math.max(0, Math.min(1, celebAlpha));
                int ca = (int)(0xFF * celebAlpha);

                String killText = "✦ Eliminated " + CombatTracker.killedPlayerName;
                int ktW = font.method_1727(killText);

                // Gold glow border
                float pulse = (float)(0.5 + 0.5 * Math.sin(elapsed * 0.008));
                int glowAlpha = (int)(0x40 * pulse * celebAlpha);
                drawRoundedRect(ctx, x - 2, y - 2, w + 4, h + 4, 14, (glowAlpha << 24) | 0xFFD700);

                ctx.method_25303(font, killText, screenW / 2 - ktW / 2, y + (h - 7) / 2, (ca << 24) | 0xFFD700);

            } else {
                // ── NORMAL COMBAT HUD ──
                int ca = Math.max(0xAA, (int)(0xFF * combatProgress));
                int headSize = 16;
                int headX = x + 6;
                int headY = y + 4;

                if (CombatTracker.opponentSkinTexture != null) {
                    ctx.method_25293(CombatTracker.opponentSkinTexture,
                        headX, headY, headSize, headSize, 8f, 8f, 8, 8, 64, 64);
                    ctx.method_25293(CombatTracker.opponentSkinTexture,
                        headX, headY, headSize, headSize, 40f, 8f, 8, 8, 64, 64);
                } else {
                    drawRoundedRect(ctx, headX, headY, headSize, headSize, 3, 0xFF333333);
                }

                int infoX = headX + headSize + 6;

                // Name + HP right-aligned
                String oppName = CombatTracker.opponentName != null ? CombatTracker.opponentName : "Unknown";
                ctx.method_25303(font, oppName, infoX, y + 5, 0xFFFFFFFF);
                String hpStr = (int)CombatTracker.opponentHealth + "/" + (int)CombatTracker.opponentMaxHealth;
                ctx.method_25303(font, hpStr, x + w - font.method_1727(hpStr) - 8, y + 5, 0x99AAAAAA);

                // Hearts row
                int heartY2 = y + 17;
                int fullHearts = (int)(CombatTracker.opponentHealth / 2);
                boolean halfHeart = (CombatTracker.opponentHealth % 2) >= 1;
                int totalHearts = Math.max(1, (int)(CombatTracker.opponentMaxHealth / 2));
                String heartChar = "\u2764";
                int charW2 = font.method_1727(heartChar);

                for (int i = 0; i < totalHearts; i++) {
                    int hx = infoX + i * charW2;
                    if (hx + charW2 > x + w - 8) break;
                    if (i < fullHearts) {
                        ctx.method_25303(font, heartChar, hx, heartY2, 0xFFFF4444);
                    } else if (i == fullHearts && halfHeart) {
                        int halfW = charW2 / 2;
                        ctx.method_44379(hx, heartY2 - 1, hx + halfW, heartY2 + 9);
                        ctx.method_25303(font, heartChar, hx, heartY2, 0xFFFF4444);
                        ctx.method_44380();
                        ctx.method_44379(hx + halfW, heartY2 - 1, hx + charW2 + 1, heartY2 + 9);
                        ctx.method_25303(font, heartChar, hx, heartY2, 0xFF333333);
                        ctx.method_44380();
                    } else {
                        ctx.method_25303(font, heartChar, hx, heartY2, 0xFF333333);
                    }
                }

                // Weapon text
                int weapTxtY = y + 28;
                if (CombatTracker.opponentWeaponName != null) {
                    String wpn = "\u2694 " + CombatTracker.opponentWeaponName;
                    int maxWpnW = w - (infoX - x) - 8;
                    if (font.method_1727(wpn) > maxWpnW) {
                        while (font.method_1727(wpn + "\u2026") > maxWpnW && wpn.length() > 3) wpn = wpn.substring(0, wpn.length() - 1);
                        wpn += "\u2026";
                    }
                    ctx.method_25303(font, wpn, infoX, weapTxtY, 0x99BBBBBB);
                }

                // Equipment row: [armor x4] | [weapon] [offhand]
                int equipY = y + 40;
                int iSz = 12;
                int iGap = 2;

                class_1799[] armor = {
                    CombatTracker.opponentHelmet, CombatTracker.opponentChestplate,
                    CombatTracker.opponentLeggings, CombatTracker.opponentBoots
                };

                for (int i = 0; i < armor.length; i++) {
                    int ix = infoX + i * (iSz + iGap);
                    drawCombatItem(ctx, armor[i], ix, equipY, iSz);
                }

                // Divider
                int divX = infoX + 4 * (iSz + iGap) + 1;
                ctx.method_25294(divX, equipY + 1, divX + 1, equipY + iSz - 1, 0x40FFFFFF);

                // Weapon item
                drawCombatItem(ctx, CombatTracker.opponentWeaponStack, divX + 3, equipY, iSz);

                // Off-hand
                if (CombatTracker.opponentOffhand != null && !CombatTracker.opponentOffhand.method_7960()) {
                    drawCombatItem(ctx, CombatTracker.opponentOffhand, divX + 3 + iSz + iGap, equipY, iSz);
                }

                // Potion effects
                if (!CombatTracker.opponentEffects.isEmpty()) {
                    int effY = equipY + iSz + 5;
                    int effX = infoX;
                    for (String eff : CombatTracker.opponentEffects) {
                        int ew = font.method_1727(eff);
                        if (effX + ew > x + w - 8) { ctx.method_25303(font, "\u2026", effX, effY, 0x55AACCFF); break; }
                        ctx.method_25303(font, eff, effX, effY, 0x99AACCFF);
                        effX += ew + 6;
                    }
                }
            }

        } else if (showWaypoint) {
            // ── WAYPOINT NAVIGATION (death-style 3-line) ──
            WaypointManager.Waypoint wp = WaypointManager.activeWaypoint;
            String header = "NAVIGATING";
            String wpCoords = wp.x + " " + wp.y + " " + wp.z;
            ctx.method_25303(font, header, screenW / 2 - font.method_1727(header) / 2, y + 5, 0x777777);
            ctx.method_25303(font, center, screenW / 2 - font.method_1727(center) / 2, y + 16, 0xFFFFFF);
            ctx.method_25303(font, wpCoords, screenW / 2 - font.method_1727(wpCoords) / 2, y + 28, 0x555555);

            // Coord feedback overlay
            if (coordFeedback != null) {
                ctx.method_25303(font, coordFeedback, x + w - font.method_1727(coordFeedback) - 8, y + 28, 0xFF44DD44);
            }

        } else if (TimerManager.hasFinishedTimer()) {
            // ── TIMER FINISHED (persistent) ──
            String header = "TIMER";
            String finishText = "⏱ " + TimerManager.finishedTimerName + " finished!";
            String hint = "auto-dismiss in " + Math.max(0, (int)((TimerManager.finishedTimerEndTime + 10000 - System.currentTimeMillis()) / 1000)) + "s";
            ctx.method_25303(font, header, screenW / 2 - font.method_1727(header) / 2, y + 5, 0x777777);
            ctx.method_25303(font, finishText, screenW / 2 - font.method_1727(finishText) / 2, y + 16, 0xFF00AAFF);
            ctx.method_25303(font, hint, screenW / 2 - font.method_1727(hint) / 2, y + 28, 0x555555);

        } else if (TimerManager.isInCountdown()) {
            // ── TIMER COUNTDOWN (last 10 seconds) ──
            long remaining = TimerManager.getRemaining(TimerManager.countdownTimer);
            String countStr = TimerManager.formatCountdown(remaining);
            String timerName = "⏱ " + TimerManager.countdownTimer.name;

            // Large countdown number
            ctx.method_25303(font, timerName, screenW / 2 - font.method_1727(timerName) / 2, y + 5, 0x888888);
            // Big countdown
            String bigCount = countStr + "s";
            ctx.method_25303(font, bigCount, screenW / 2 - font.method_1727(bigCount) / 2, y + 17, 0xFF00AAFF);

        } else if (showDeath) {
            String header = "FINDING";
            String coords = GameAlerts.getDeathCoords();
            ctx.method_25303(font, header, screenW / 2 - font.method_1727(header) / 2, y + 5, 0x777777);
            ctx.method_25303(font, center, screenW / 2 - font.method_1727(center) / 2, y + 16, 0xFFFFFF);
            ctx.method_25303(font, coords, screenW / 2 - font.method_1727(coords) / 2, y + 28, 0x555555);

        // Background media playback indicator — styled like music player (BEFORE idle text!)
        } else if (MediaViewer.isPlayingInBackground() && !mediaOpen && !hasNotif && !showCombat) {
            int compactH = 34;
            int sourceColor = MediaViewer.mediaType == MediaViewer.MediaType.TWITCH ? 0x9146FF : 0xFF0000;
            boolean isPlaying = MediaViewer.isPlaying();

            // Source badge (small rounded pill with "YT" or "TW")
            String badge = MediaViewer.mediaType == MediaViewer.MediaType.TWITCH ? "TW" : "YT";
            int badgeW = font.method_1727(badge) + 6;
            int badgeH = 10;
            int badgeX = x + 6;
            int badgeY = y + (compactH - badgeH) / 2;
            drawRoundedRect(ctx, badgeX, badgeY, badgeW, badgeH, 3, 0xFF000000 | sourceColor);
            ctx.method_25303(font, badge, badgeX + 3, badgeY + 1, 0xFFFFFFFF);

            // Title + source label
            int textX = badgeX + badgeW + 5;
            String bgTitle = MediaViewer.currentTitle;
            int titleMaxW3 = w - badgeW - 42;
            if (font.method_1727(bgTitle) > titleMaxW3) {
                while (font.method_1727(bgTitle + "...") > titleMaxW3 && bgTitle.length() > 1)
                    bgTitle = bgTitle.substring(0, bgTitle.length() - 1);
                bgTitle += "...";
            }
            ctx.method_25303(font, bgTitle, textX, y + 7, 0xFFDDDDDD);
            String sourceLabel2 = MediaViewer.mediaType == MediaViewer.MediaType.TWITCH ? "Twitch" : "YouTube";
            ctx.method_25303(font, sourceLabel2, textX, y + 18, 0xFF888888);

            // EQ bars (like music player)
            int eqX = x + w - 18;
            int eqY = y + 8;
            long nowMs = System.currentTimeMillis();
            if (isPlaying) {
                int eqColor = 0xFF000000 | sourceColor;
                drawEqBar(ctx, eqX,     eqY, 3, 14, eqColor, nowMs, 1.0, 0.0);
                drawEqBar(ctx, eqX + 4, eqY, 3, 14, eqColor, nowMs, 1.4, 1.5);
                drawEqBar(ctx, eqX + 8, eqY, 3, 14, eqColor, nowMs, 0.9, 3.0);
            } else {
                ctx.method_25294(eqX, eqY + 7, eqX + 3, eqY + 14, 0xFF666666);
                ctx.method_25294(eqX + 4, eqY + 4, eqX + 7, eqY + 14, 0xFF666666);
                ctx.method_25294(eqX + 8, eqY + 9, eqX + 11, eqY + 14, 0xFF666666);
            }

            // Progress bar at bottom (like music player)
            long pos = MediaViewer.getPosition();
            long dur = MediaViewer.getDuration();
            int barY3 = y + compactH - 4;
            int barX3 = x + 14;
            int barW3 = w - 28;
            ctx.method_25294(barX3, barY3, barX3 + barW3, barY3 + 2, 0x30FFFFFF);
            if (dur > 0) {
                int filled = (int)(barW3 * pos / (float) dur);
                if (filled > 0) ctx.method_25294(barX3, barY3, barX3 + filled, barY3 + 2, 0xFF000000 | sourceColor);
            }

        // Browser background playback indicator
        } else if (InGameBrowser.isPlayingInBackground() && !mediaOpen && !hasNotif && !showCombat) {
            int compactH = 34;
            String currentUrl = InGameBrowser.getCurrentUrl();
            boolean isTwitch = currentUrl.contains("twitch.tv");
            int sourceColor = isTwitch ? 0x9146FF : 0xFF0000;

            // Source badge
            String badge = isTwitch ? "TW" : "YT";
            int badgeW = font.method_1727(badge) + 6;
            int badgeH = 10;
            int badgeX = x + 6;
            int badgeY = y + (compactH - badgeH) / 2;
            drawRoundedRect(ctx, badgeX, badgeY, badgeW, badgeH, 3, 0xFF000000 | sourceColor);
            ctx.method_25303(font, badge, badgeX + 3, badgeY + 1, 0xFFFFFFFF);

            // Title
            int textX = badgeX + badgeW + 5;
            String bgTitle = InGameBrowser.pageTitle;
            if (bgTitle.isEmpty()) bgTitle = isTwitch ? "Twitch" : "YouTube";
            int titleMaxW3 = w - badgeW - 42;
            if (font.method_1727(bgTitle) > titleMaxW3) {
                while (font.method_1727(bgTitle + "...") > titleMaxW3 && bgTitle.length() > 1)
                    bgTitle = bgTitle.substring(0, bgTitle.length() - 1);
                bgTitle += "...";
            }
            ctx.method_25303(font, bgTitle, textX, y + 7, 0xFFDDDDDD);
            String sourceLabel = isTwitch ? "Twitch" : "YouTube";
            ctx.method_25303(font, sourceLabel, textX, y + 18, 0xFF888888);

            // Animated EQ bars
            int eqX = x + w - 18;
            int eqY = y + 8;
            long nowMs = System.currentTimeMillis();
            int eqColor = 0xFF000000 | sourceColor;
            drawEqBar(ctx, eqX,     eqY, 3, 14, eqColor, nowMs, 1.0, 0.0);
            drawEqBar(ctx, eqX + 4, eqY, 3, 14, eqColor, nowMs, 1.4, 1.5);
            drawEqBar(ctx, eqX + 8, eqY, 3, 14, eqColor, nowMs, 0.9, 3.0);

        } else if (!center.isEmpty() && !showMusic) {
            int textY = y + ((h - (showBiome ? 12 : 0)) - 7) / 2;
            int textColor = theme.textColor;
            ctx.method_25303(font, center, screenW / 2 - font.method_1727(center) / 2, textY, textColor);

            // Coord feedback overlay
            if (coordFeedback != null) {
                ctx.method_25303(font, coordFeedback, x + w - font.method_1727(coordFeedback) - 8, textY, 0xFF44DD44);
            }
        } else if (showMusic) {
            int compactH = 34;
            int artSize = 22;
            int artX = x + 5;
            int artY = y + (compactH - artSize) / 2;

            if (albumTextureId != null && !albumLoading) {
                ctx.method_25290(albumTextureId, artX, artY, 0, 0, artSize, artSize, artSize, artSize);
                drawCircleMask(ctx, artX, artY, artSize, bg);
            } else {
                drawFilledCircle(ctx, artX, artY, artSize, 0xFF1A1A1A);
            }

            int textX = artX + artSize + 6;
            ctx.method_25303(font, line1, textX, y + 7, 0xDDDDDD);
            ctx.method_25303(font, line2, textX, y + 18, 0x888888);

            int eqX = x + w - 18;
            int eqY = y + 8;
            long now = System.currentTimeMillis();

            if (musicPlaying) {
                int eqColor = 0xFF55DD55;
                drawEqBar(ctx, eqX,     eqY, 3, 14, eqColor, now, 1.0, 0.0);
                drawEqBar(ctx, eqX + 4, eqY, 3, 14, eqColor, now, 1.4, 1.5);
                drawEqBar(ctx, eqX + 8, eqY, 3, 14, eqColor, now, 0.9, 3.0);
            } else {
                ctx.method_25294(eqX, eqY + 7, eqX + 3, eqY + 14, 0xFF666666);
                ctx.method_25294(eqX + 4, eqY + 4, eqX + 7, eqY + 14, 0xFF666666);
                ctx.method_25294(eqX + 8, eqY + 9, eqX + 11, eqY + 14, 0xFF666666);
            }

            boolean lyricsActive = DynamicIslandMod.isLyricsMode && state.spotify.lyrics != null && state.spotify.lyrics.length > 0;

            // ── Progress bar (hide during lyrics) ──
            if (!lyricsActive) {
                int barY = y + compactH - 4;
                int barX = x + 14;
                int barW = w - 28;
                ctx.method_25294(barX, barY, barX + barW, barY + 2, 0x30FFFFFF);
                int filled = (int)(barW * displayProgress);
                if (filled > 0) ctx.method_25294(barX, barY, barX + filled, barY + 2, 0xAAFFFFFF);
            }

            if (expandProgress > 0.01f && !lyricsActive) {
                int controlsY = y + compactH + (int)(2 * expandProgress);
                long estimatedMs = (long)(displayProgress * serverDuration);
                String timeStr = formatMs(estimatedMs) + " / " + formatMs(serverDuration);
                int timeColor = ((int)(0xAA * expandProgress) << 24) | 0xAAAAAA;
                ctx.method_25303(font, timeStr, x + 8, controlsY + 2, timeColor);

                String controls = "M: collapse";
                int ctrlColor = ((int)(0x66 * expandProgress) << 24) | 0x888888;
                ctx.method_25303(font, controls, x + w - font.method_1727(controls) - 8, controlsY + 2, ctrlColor);
            }

            // ── Lyrics rendering ───────────────────
            if (lyricsActive) {
                LauncherState.LyricsLine[] lyrics = state.spotify.lyrics;

                // Divider between music header and lyrics
                int divY = y + compactH + 1;
                ctx.method_25294(x + 12, divY, x + w - 12, divY + 1, 0x20FFFFFF);

                // Use real-time position (not interpolated) for accurate sync
                long realMs;
                if (serverPlaying && serverDuration > 0) {
                    long elapsed = System.currentTimeMillis() - serverUpdateTime;
                    realMs = (long)(serverProgress * serverDuration) + elapsed;
                } else {
                    realMs = (long)(serverProgress * serverDuration);
                }

                // Find current line based on real-time position
                int currentIdx = 0;
                for (int i = 0; i < lyrics.length; i++) {
                    if (lyrics[i].time <= realMs + 3000) currentIdx = i;
                    else break;
                }

                // Smooth scroll
                float targetScroll = currentIdx;
                lyricsScrollOffset += (targetScroll - lyricsScrollOffset) * 0.12f;
                float frac = lyricsScrollOffset - (int) lyricsScrollOffset;

                int lineH = 14;
                // Center lyrics in usable area (below header, above progress bar)
                int lyricsMidY = y + compactH + (h - compactH) / 2 + 5;
                int scrollPx = (int)(frac * lineH);

                int greenColor = 0xFF1DB954;
                int dimColor = 0x44AAAAAA;
                int baseIdx = (int) lyricsScrollOffset;

                for (int offset = -1; offset <= 1; offset++) {
                    int idx = baseIdx + offset;
                    if (idx < 0 || idx >= lyrics.length) continue;

                    String lyricText = lyrics[idx].text;
                    int maxLW = w - 24;
                    if (font.method_1727(lyricText) > maxLW) {
                        while (font.method_1727(lyricText + "...") > maxLW && lyricText.length() > 0)
                            lyricText = lyricText.substring(0, lyricText.length() - 1);
                        lyricText += "...";
                    }

                    int drawY = lyricsMidY + (offset * lineH) - scrollPx - 4;
                    int color = (offset == 0) ? greenColor : dimColor;
                    int lyricX = screenW / 2 - font.method_1727(lyricText) / 2;
                    ctx.method_25303(font, lyricText, lyricX, drawY, color);
                }

                // Thin green progress at very bottom
                int pbarY = y + h - 2;
                int pbarX = x + 16;
                int pbarW = w - 32;
                ctx.method_25294(pbarX, pbarY, pbarX + pbarW, pbarY + 1, 0x15FFFFFF);
                int pFilled = (int)(pbarW * displayProgress);
                if (pFilled > 0) ctx.method_25294(pbarX, pbarY, pbarX + pFilled, pbarY + 1, 0x661DB954);

                String hint = "K: close";
                ctx.method_25303(font, hint, x + w - font.method_1727(hint) - 10, y + h - 11, 0x22888888);
            }
        }

       } // end panel content gate

        // ── Coordinate click handling ──────────────
        if (DynamicIslandMod.displayedCoords != null && client.field_1755 == null) {
            // Check if mouse is over the pill
            double mx = client.field_1729.method_1603() / client.method_22683().method_4495();
            double my = client.field_1729.method_1604() / client.method_22683().method_4495();
            if (mx >= x && mx <= x + w && my >= y && my <= y + h) {
                // Left click = copy, Right click = share
                if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(client.method_22683().method_4490(), 0) == 1) {
                    client.field_1774.method_1455(DynamicIslandMod.displayedCoords);
                    coordFeedback = "Copied!";
                    coordFeedbackUntil = System.currentTimeMillis() + 2000;
                    DynamicIslandMod.displayedCoords = null; // prevent repeat
                } else if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(client.method_22683().method_4490(), 1) == 1) {
                    client.method_1562().method_45729("My location is " + DynamicIslandMod.displayedCoords);
                    coordFeedback = "Shared!";
                    coordFeedbackUntil = System.currentTimeMillis() + 2000;
                    DynamicIslandMod.displayedCoords = null;
                }
            }
        }

        // Biome footnote
        if (showBiome && !hasNotif && pebbleProgress < 0.1f && notifCenterProgress < 0.1f && settingsProgress < 0.1f && mediaProgress < 0.1f && GameAlerts.biomeSubtitle != null) {
            String biome = GameAlerts.biomeSubtitle;
            ctx.method_25303(font, biome, screenW / 2 - font.method_1727(biome) / 2, y + h - 10, 0x666666);
        }

        // ════════════════════════════════════════════════
        // PEBBLE CHAT (inside the pill)
        // ════════════════════════════════════════════════
        if (pebbleOpen && pebbleProgress > 0.01f) {
            int pa = (int)(0xFF * pebbleProgress);

            // Header: "Loomie AI" with purple cross accent
            int headerY = y + 6;
            int accentColor = (pa << 24) | 0x9B7DFF;
            int titleColor = (pa << 24) | 0xFFFFFF;
            int subtitleColor = ((int)(0x77 * pebbleProgress) << 24) | 0x777777;

            // Purple cross icon
            ctx.method_25294(x + 10, headerY + 1, x + 17, headerY + 6, accentColor);
            ctx.method_25294(x + 12, headerY - 1, x + 15, headerY + 8, accentColor);
            ctx.method_25303(font, "Loomie", x + 20, headerY, titleColor);
            ctx.method_25303(font, "AI", x + 20 + font.method_1727("Loomie "), headerY, subtitleColor);

            // Separator
            int sepY = headerY + 12;
            ctx.method_25294(x + 8, sepY, x + w - 8, sepY + 1, ((int)(0x20 * pebbleProgress) << 24) | 0xFFFFFF);

            // Message area
            int msgTop = sepY + 3;
            int inputH = 18;
            int msgBottom = y + h - inputH - 6;
            int msgAreaH = msgBottom - msgTop;
            int contentW = w - 20;

            // Calculate total content height
            java.util.List<DynamicIslandMod.PebbleChatMsg> msgs = DynamicIslandMod.pebbleMessages;
            int totalH = 4;
            for (DynamicIslandMod.PebbleChatMsg msg : msgs) {
                totalH += pebbleBubbleH(font, msg.text, contentW) + 5;
            }
            if (DynamicIslandMod.pebbleWaiting) totalH += 16;

            // Clamp scroll
            int overflow = Math.max(0, totalH - msgAreaH);
            DynamicIslandMod.pebbleScroll = Math.max(0, Math.min(DynamicIslandMod.pebbleScroll, overflow));

            int startY;
            if (totalH <= msgAreaH) {
                startY = msgTop;
            } else {
                startY = msgTop - (totalH - msgAreaH) + DynamicIslandMod.pebbleScroll;
            }

            ctx.method_44379(x + 2, msgTop, x + w - 2, msgBottom);

            int my = startY;
            for (DynamicIslandMod.PebbleChatMsg msg : msgs) {
                int bubbleH = pebbleBubbleH(font, msg.text, contentW);
                java.util.List<String> lines = pebbleWrap(font, msg.text, contentW - 14);
                int textMaxW = 0;
                for (String l : lines) textMaxW = Math.max(textMaxW, font.method_1727(l));
                int bW = Math.min(contentW, textMaxW + 16);

                if (msg.isUser) {
                    // User: right-aligned, dark bg
                    int bX = x + w - 10 - bW;
                    drawRoundedRect(ctx, bX, my, bW, bubbleH, 5, ((int)(0xDD * pebbleProgress) << 24) | 0x2A2A2A);
                    int ly = my + 5;
                    for (String l : lines) {
                        ctx.method_25303(font, l, bX + 7, ly, titleColor);
                        ly += 10;
                    }
                } else {
                    // Pebble: left-aligned, accent bar
                    int bX = x + 10;
                    drawRoundedRect(ctx, bX, my, bW, bubbleH, 5, ((int)(0xDD * pebbleProgress) << 24) | 0x1E1E1E);
                    ctx.method_25294(bX + 1, my + 4, bX + 3, my + bubbleH - 4, accentColor);
                    int ly = my + 5;
                    for (String l : lines) {
                        ctx.method_25303(font, l, bX + 8, ly, titleColor);
                        ly += 10;
                    }
                }
                my += bubbleH + 5;
            }

            // Typing indicator
            if (DynamicIslandMod.pebbleWaiting) {
                long now = System.currentTimeMillis();
                if (now - DynamicIslandMod.pebbleLastDotTime > 350) {
                    DynamicIslandMod.pebbleTypingDots = (DynamicIslandMod.pebbleTypingDots + 1) % 4;
                    DynamicIslandMod.pebbleLastDotTime = now;
                }
                for (int i = 0; i < 3; i++) {
                    int dotA = (i < DynamicIslandMod.pebbleTypingDots) ? (int)(0xDD * pebbleProgress) : (int)(0x33 * pebbleProgress);
                    ctx.method_25294(x + 18 + i * 7, my + 3, x + 21 + i * 7, my + 6, (dotA << 24) | 0x9B7DFF);
                }
            }

            ctx.method_44380();

            // Empty state
            if (msgs.isEmpty() && !DynamicIslandMod.pebbleWaiting) {
                String e = "Ask anything about Minecraft...";
                int eColor = ((int)(0x55 * pebbleProgress) << 24) | 0x555555;
                ctx.method_25303(font, e, screenW / 2 - font.method_1727(e) / 2, y + h / 2 - 4, eColor);
            }

            // Input field visual
            int inY = y + h - inputH - 3;
            int inX = x + 8;
            int inW = w - 16;
            drawRoundedRect(ctx, inX, inY, inW, inputH, 9, ((int)(0xDD * pebbleProgress) << 24) | 0x2A2A2A);

            String inputText = DynamicIslandMod.pebbleInputText;
            if (inputText.isEmpty()) {
                int phColor = ((int)(0x66 * pebbleProgress) << 24) | 0x666666;
                ctx.method_25303(font, "Type a question...", inX + 8, inY + 5, phColor);
            } else {
                // Truncate from left if too wide
                int maxTW = inW - 18;
                String display = inputText;
                if (font.method_1727(display) > maxTW) {
                    while (font.method_1727("..." + display) > maxTW && display.length() > 0)
                        display = display.substring(1);
                    display = "..." + display;
                }
                ctx.method_25303(font, display, inX + 8, inY + 5, titleColor);
                // Blinking cursor
                if (System.currentTimeMillis() % 1000 < 500) {
                    int curX = inX + 8 + font.method_1727(display);
                    ctx.method_25294(curX + 1, inY + 4, curX + 2, inY + 14, titleColor);
                }
            }

        }

        // ════════════════════════════════════════════════
        // NOTIFICATION CENTER (tabbed: Notifications | Waypoints | Timers)
        // ════════════════════════════════════════════════
        if (notifOpen && notifCenterProgress > 0.01f) {
            int pa = (int)(0xFF * notifCenterProgress);

            // Header
            int headerY = y + 6;
            int bellColor = (pa << 24) | 0xFFAA00;
            int titleColor = (pa << 24) | 0xFFFFFF;
            int dimColor = ((int)(0x66 * notifCenterProgress) << 24) | 0x888888;
            ctx.method_25303(font, "\uD83D\uDD14", x + 10, headerY, bellColor);
            ctx.method_25303(font, "Notification Center", x + 22, headerY, titleColor);

            // Tabs
            int tabY = headerY + 14;
            String[] ncTabs = {"Notifications", "Waypoints", "Timers"};
            int tabX = x + 10;
            for (int t = 0; t < ncTabs.length; t++) {
                boolean active = (DynamicIslandMod.notifCenterTab == t);
                int tColor = active ? ((pa << 24) | 0xFFAA00) : dimColor;
                ctx.method_25303(font, ncTabs[t], tabX, tabY, tColor);
                if (active) {
                    int tw = font.method_1727(ncTabs[t]);
                    ctx.method_25294(tabX, tabY + 10, tabX + tw, tabY + 11, (pa << 24) | 0xFFAA00);
                }
                // Tab click
                if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                    int cx = DynamicIslandMod.notifClickX;
                    int cy = DynamicIslandMod.notifClickY;
                    if (cx >= tabX && cx <= tabX + font.method_1727(ncTabs[t]) && cy >= tabY - 2 && cy <= tabY + 12) {
                        DynamicIslandMod.notifCenterTab = t;
                        DynamicIslandMod.notifCenterScroll = 0;
                    }
                }
                tabX += font.method_1727(ncTabs[t]) + 14;
            }

            // Separator
            int sepY = tabY + 14;
            ctx.method_25294(x + 8, sepY, x + w - 8, sepY + 1, ((int)(0x20 * notifCenterProgress) << 24) | 0xFFFFFF);

            int listTop = sepY + 3;
            int listBottom = y + h - 4;
            int listH = listBottom - listTop;

            ctx.method_44379(x + 2, listTop, x + w - 2, listBottom);

            if (DynamicIslandMod.notifCenterTab == 0) {
                // ── NOTIFICATIONS TAB ──
                String clearHint = "C: clear";
                int hintColor = ((int)(0x44 * notifCenterProgress) << 24) | 0x888888;
                ctx.method_25303(font, clearHint, x + w - font.method_1727(clearHint) - 10, listTop, hintColor);

                java.util.List<DynamicIslandMod.NotifEntry> notifs = DynamicIslandMod.notifHistory;
                int totalH = 14; // space for hint
                for (int i = 0; i < notifs.size(); i++) totalH += 14;

                int overflow = Math.max(0, totalH - listH);
                DynamicIslandMod.notifCenterScroll = Math.max(0, Math.min(DynamicIslandMod.notifCenterScroll, overflow));

                int ny = listTop + 14;
                if (totalH > listH) ny = listTop + 14 - (totalH - listH) + DynamicIslandMod.notifCenterScroll;

                long now = System.currentTimeMillis();
                for (DynamicIslandMod.NotifEntry entry : notifs) {
                    int dotColor;
                    switch (entry.type) {
                        case "whisper" -> dotColor = 0xFF9B7DFF;
                        case "health" -> dotColor = 0xFFFF4444;
                        case "hunger" -> dotColor = 0xFFCC8844;
                        case "durability" -> dotColor = 0xFFFF6600;
                        case "player" -> dotColor = 0xFF44DD44;
                        case "inventory" -> dotColor = 0xFFAAAA00;
                        case "death" -> dotColor = 0xFFDD2222;
                        case "timer" -> dotColor = 0xFF00AAFF;
                        case "waypoint" -> dotColor = 0xFF4CAF50;
                        case "combat" -> dotColor = 0xFFFF3333;
                        default -> dotColor = 0xFF888888;
                    }
                    int dotAlpha = (int)(0xFF * notifCenterProgress);
                    ctx.method_25294(x + 10, ny + 3, x + 13, ny + 6, (dotAlpha << 24) | (dotColor & 0xFFFFFF));

                    String notifText = entry.text;
                    int maxNW = w - 70;
                    if (font.method_1727(notifText) > maxNW) {
                        while (font.method_1727(notifText + "...") > maxNW && notifText.length() > 0)
                            notifText = notifText.substring(0, notifText.length() - 1);
                        notifText += "...";
                    }
                    ctx.method_25303(font, notifText, x + 16, ny + 1, (pa << 24) | 0xCCCCCC);

                    String timeStr = relativeTime(now - entry.timestamp);
                    int timeCol = ((int)(0x55 * notifCenterProgress) << 24) | 0x777777;
                    ctx.method_25303(font, timeStr, x + w - font.method_1727(timeStr) - 10, ny + 1, timeCol);
                    ny += 14;
                }

                if (notifs.isEmpty()) {
                    String e = "No notifications";
                    int eColor = ((int)(0x55 * notifCenterProgress) << 24) | 0x555555;
                    ctx.method_25303(font, e, screenW / 2 - font.method_1727(e) / 2, y + h / 2 - 4, eColor);
                }

            } else if (DynamicIslandMod.notifCenterTab == 1) {
                // ── WAYPOINTS TAB ──
                java.util.List<WaypointManager.Waypoint> wps = WaypointManager.getWaypoints();
                int wy = listTop + 2;

                // Save current location button
                String saveBtn = "\uD83D\uDCCD Save Current Location";
                int saveBtnW = font.method_1727(saveBtn) + 12;
                drawRoundedRect(ctx, x + 10, wy, saveBtnW, 14, 4, ((int)(0xDD * notifCenterProgress) << 24) | 0x2A2A2A);
                ctx.method_25303(font, saveBtn, x + 16, wy + 3, (pa << 24) | 0x4CAF50);

                if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                    int cx = DynamicIslandMod.notifClickX;
                    int cy = DynamicIslandMod.notifClickY;
                    if (cx >= x + 10 && cx <= x + 10 + saveBtnW && cy >= wy && cy <= wy + 14) {
                        if (client.field_1724 != null) {
                            int px = (int) client.field_1724.method_23317();
                            int py = (int) client.field_1724.method_23318();
                            int pz = (int) client.field_1724.method_23321();
                            String dim = client.field_1687 != null ? client.field_1687.method_27983().method_29177().method_12832() : "overworld";
                            WaypointManager.addWaypoint("WP " + (wps.size() + 1), px, py, pz, dim);
                        }
                    }
                }

                // Cancel route button (if navigating)
                if (WaypointManager.activeWaypoint != null) {
                    wy += 18;
                    String cancelBtn = "✕ Cancel Route";
                    int cancelW = font.method_1727(cancelBtn) + 12;
                    drawRoundedRect(ctx, x + 10, wy, cancelW, 14, 4, ((int)(0xDD * notifCenterProgress) << 24) | 0x3A1A1A);
                    ctx.method_25303(font, cancelBtn, x + 16, wy + 3, (pa << 24) | 0xFF6644);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= x + 10 && cx <= x + 10 + cancelW && cy >= wy && cy <= wy + 14) {
                            WaypointManager.cancelNavigation();
                        }
                    }
                }

                // Cancel death tracking button (if death is active)
                if (GameAlerts.deathActive) {
                    wy += 18;
                    String deathBtn = "✕ Cancel Death Tracking";
                    int deathW = font.method_1727(deathBtn) + 12;
                    drawRoundedRect(ctx, x + 10, wy, deathW, 14, 4, ((int)(0xDD * notifCenterProgress) << 24) | 0x3A1A1A);
                    ctx.method_25303(font, deathBtn, x + 16, wy + 3, (pa << 24) | 0xFF4444);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= x + 10 && cx <= x + 10 + deathW && cy >= wy && cy <= wy + 14) {
                            GameAlerts.deathActive = false;
                            GameAlerts.deathPos = null;
                            GameAlerts.persistentText = null;
                            GameAlerts.persistentType = null;
                        }
                    }
                }

                wy += 20;

                // Waypoint list
                for (int i = 0; i < wps.size(); i++) {
                    WaypointManager.Waypoint wp = wps.get(i);
                    boolean isActive = wp == WaypointManager.activeWaypoint;

                    // Color dot
                    ctx.method_25294(x + 10, wy + 2, x + 14, wy + 6, wp.color);

                    // Name
                    String wpName = wp.name;
                    ctx.method_25303(font, wpName, x + 18, wy, isActive ? ((pa << 24) | 0xFFAA00) : titleColor);

                    // Coords + dimension
                    String wpCoords = wp.x + " " + wp.y + " " + wp.z + " [" + WaypointManager.getDimensionShort(wp.dimension) + "]";
                    ctx.method_25303(font, wpCoords, x + 18 + font.method_1727(wpName) + 6, wy, dimColor);

                    // Click to navigate
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= x + 10 && cx <= x + w - 40 && cy >= wy - 2 && cy <= wy + 12) {
                            WaypointManager.startNavigation(i);
                        }
                    }

                    // Right-click to delete
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 1) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= x + 10 && cx <= x + w - 10 && cy >= wy - 2 && cy <= wy + 12) {
                            WaypointManager.removeWaypoint(i);
                            break; // list modified, break out
                        }
                    }

                    wy += 14;
                }

                if (wps.isEmpty()) {
                    String e = "No waypoints saved";
                    int eColor = ((int)(0x55 * notifCenterProgress) << 24) | 0x555555;
                    ctx.method_25303(font, e, screenW / 2 - font.method_1727(e) / 2, listTop + listH / 2 - 4, eColor);
                }

                // Count
                String countStr = wps.size() + "/20";
                ctx.method_25303(font, countStr, x + w - font.method_1727(countStr) - 10, listTop + 2, dimColor);

            } else if (DynamicIslandMod.notifCenterTab == 2) {
                // ── TIMERS TAB (Apple-style) ──
                int ty = listTop + 2;

                // Finished timer (must dismiss)
                if (TimerManager.hasFinishedTimer()) {
                    String ft = "⏱ " + TimerManager.finishedTimerName + " finished!";
                    ctx.method_25303(font, ft, x + 10, ty, (pa << 24) | 0x00AAFF);

                    // Dismiss X
                    String dismiss = "✕";
                    int dismissX = x + w - font.method_1727(dismiss) - 12;
                    ctx.method_25303(font, dismiss, dismissX, ty, (pa << 24) | 0xFF4444);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= dismissX - 4 && cx <= dismissX + 12 && cy >= ty - 2 && cy <= ty + 12) {
                            TimerManager.dismissFinishedTimer();
                        }
                    }

                    // Restart button
                    String restart = "↻";
                    int restartX = dismissX - font.method_1727(restart) - 10;
                    ctx.method_25303(font, restart, restartX, ty, (pa << 24) | 0x44DD44);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= restartX - 4 && cx <= restartX + 12 && cy >= ty - 2 && cy <= ty + 12) {
                            TimerManager.restartFinishedTimer();
                        }
                    }
                    ty += 18;
                    ctx.method_25294(x + 8, ty, x + w - 8, ty + 1, ((int)(0x15 * notifCenterProgress) << 24) | 0xFFFFFF);
                    ty += 6;
                }

                // Active timers
                java.util.List<TimerManager.TimerData> timers = TimerManager.getActiveTimers();
                for (int i = 0; i < timers.size(); i++) {
                    TimerManager.TimerData timer = timers.get(i);
                    long remaining = TimerManager.getRemaining(timer);
                    String timerStr = "⏱ " + timer.name + " — " + TimerManager.formatTime(remaining);
                    ctx.method_25303(font, timerStr, x + 10, ty, titleColor);

                    String cancel = "✕";
                    int cancelX = x + w - font.method_1727(cancel) - 12;
                    ctx.method_25303(font, cancel, cancelX, ty, (pa << 24) | 0xFF4444);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= cancelX - 4 && cx <= cancelX + 12 && cy >= ty - 2 && cy <= ty + 12) {
                            TimerManager.cancelTimer(i);
                            break;
                        }
                    }
                    ty += 16;
                }

                if (timers.isEmpty() && !TimerManager.hasFinishedTimer()) {
                    ctx.method_25303(font, "No active timers", x + 10, ty, dimColor);
                    ty += 16;
                }

                ty += 8;
                ctx.method_25294(x + 8, ty, x + w - 8, ty + 1, ((int)(0x15 * notifCenterProgress) << 24) | 0xFFFFFF);
                ty += 8;

                // ── Apple-style picker (Hours : Minutes : Seconds) ──
                int pickerCenterX = screenW / 2;
                int colW = 36;
                int colGap = 8;

                // Column labels
                String[] labels = {"hours", "min", "sec"};
                int[] vals = {TimerManager.pickerHours, TimerManager.pickerMinutes, TimerManager.pickerSeconds};
                int[] maxVals = {23, 59, 59};

                for (int col = 0; col < 3; col++) {
                    int colX = pickerCenterX + (col - 1) * (colW + colGap) - colW / 2;

                    // Up arrow
                    String upArr = "▲";
                    int upX = colX + colW / 2 - font.method_1727(upArr) / 2;
                    ctx.method_25303(font, upArr, upX, ty, dimColor);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= colX && cx <= colX + colW && cy >= ty - 2 && cy <= ty + 10) {
                            if (col == 0) TimerManager.pickerHours = (TimerManager.pickerHours + 1) % (maxVals[0] + 1);
                            else if (col == 1) TimerManager.pickerMinutes = (TimerManager.pickerMinutes + 1) % (maxVals[1] + 1);
                            else TimerManager.pickerSeconds = (TimerManager.pickerSeconds + 1) % (maxVals[2] + 1);
                        }
                    }

                    // Value
                    String valStr = String.valueOf(vals[col]);
                    drawRoundedRect(ctx, colX, ty + 12, colW, 16, 4, ((int)(0xDD * notifCenterProgress) << 24) | 0x2A2A2A);
                    ctx.method_25303(font, valStr, colX + colW / 2 - font.method_1727(valStr) / 2, ty + 16, (pa << 24) | 0x00AAFF);

                    // Down arrow
                    String dnArr = "▼";
                    int dnX = colX + colW / 2 - font.method_1727(dnArr) / 2;
                    ctx.method_25303(font, dnArr, dnX, ty + 32, dimColor);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= colX && cx <= colX + colW && cy >= ty + 30 && cy <= ty + 42) {
                            if (col == 0) TimerManager.pickerHours = (TimerManager.pickerHours - 1 + maxVals[0] + 1) % (maxVals[0] + 1);
                            else if (col == 1) TimerManager.pickerMinutes = (TimerManager.pickerMinutes - 1 + maxVals[1] + 1) % (maxVals[1] + 1);
                            else TimerManager.pickerSeconds = (TimerManager.pickerSeconds - 1 + maxVals[2] + 1) % (maxVals[2] + 1);
                        }
                    }

                    // Label
                    ctx.method_25303(font, labels[col], colX + colW / 2 - font.method_1727(labels[col]) / 2, ty + 44, dimColor);
                }

                ty += 58;

                // Start button
                String startBtn = "▶ Start";
                int startW = font.method_1727(startBtn) + 16;
                int startX = pickerCenterX - startW / 2;
                drawRoundedRect(ctx, startX, ty, startW, 14, 6, ((int)(0xDD * notifCenterProgress) << 24) | 0x1A3A1A);
                ctx.method_25303(font, startBtn, startX + 8, ty + 3, (pa << 24) | 0x44DD44);
                if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                    int cx = DynamicIslandMod.notifClickX;
                    int cy = DynamicIslandMod.notifClickY;
                    if (cx >= startX && cx <= startX + startW && cy >= ty && cy <= ty + 14) {
                        TimerManager.startFromPicker();
                    }
                }
                ty += 20;

                // Presets
                ctx.method_25303(font, "Presets", x + 10, ty, titleColor);
                ty += 14;
                String[][] quickTimers = {{"1m", "60"}, {"5m", "300"}, {"10m", "600"}, {"30m", "1800"}};
                int btnX = x + 10;
                for (String[] qt : quickTimers) {
                    int btnW = font.method_1727(qt[0]) + 10;
                    drawRoundedRect(ctx, btnX, ty, btnW, 13, 4, ((int)(0xDD * notifCenterProgress) << 24) | 0x2A2A2A);
                    ctx.method_25303(font, qt[0], btnX + 5, ty + 3, (pa << 24) | 0x00AAFF);
                    if (DynamicIslandMod.notifClickPending && DynamicIslandMod.notifClickButton == 0) {
                        int cx = DynamicIslandMod.notifClickX;
                        int cy = DynamicIslandMod.notifClickY;
                        if (cx >= btnX && cx <= btnX + btnW && cy >= ty && cy <= ty + 13) {
                            TimerManager.startTimer(qt[0] + " Timer", Long.parseLong(qt[1]) * 1000);
                        }
                    }
                    btnX += btnW + 6;
                }
            }

            ctx.method_44380();

            // Consume click
            DynamicIslandMod.notifClickPending = false;
        }

        // ════════════════════════════════════════════════
        // SETTINGS PANEL
        // ════════════════════════════════════════════════
        if (settingsOpen && settingsProgress > 0.01f) {
            int pa = (int)(0xFF * settingsProgress);
            int titleColor = (pa << 24) | 0xFFFFFF;
            int dimColor = ((int)(0x66 * settingsProgress) << 24) | 0x888888;

            // Header
            int headerY = y + 6;
            ctx.method_25303(font, "\u2699", x + 10, headerY, (pa << 24) | 0xAAAAAA);
            ctx.method_25303(font, "Settings", x + 22, headerY, titleColor);

            // Tabs
            int tabY = headerY + 14;
            String[] tabs = {"Keybinds", "Alerts", "Inventory", "Themes"};
            int tabX = x + 10;
            for (int t = 0; t < tabs.length; t++) {
                boolean active = (DynamicIslandMod.settingsTab == t);
                int tColor = active ? ((pa << 24) | 0x9B7DFF) : dimColor;
                ctx.method_25303(font, tabs[t], tabX, tabY, tColor);
                if (active) {
                    int tw = font.method_1727(tabs[t]);
                    ctx.method_25294(tabX, tabY + 10, tabX + tw, tabY + 11, (pa << 24) | 0x9B7DFF);
                }

                // Handle tab clicks
                if (DynamicIslandMod.settingsClickPending) {
                    int cx = DynamicIslandMod.settingsClickX;
                    int cy = DynamicIslandMod.settingsClickY;
                    if (cx >= tabX && cx <= tabX + font.method_1727(tabs[t]) && cy >= tabY - 2 && cy <= tabY + 12) {
                        DynamicIslandMod.settingsTab = t;
                    }
                }
                tabX += font.method_1727(tabs[t]) + 14;
            }

            // Separator
            int sepY = tabY + 14;
            ctx.method_25294(x + 8, sepY, x + w - 8, sepY + 1, ((int)(0x15 * settingsProgress) << 24) | 0xFFFFFF);

            int contentY = sepY + 4;
            int contentBottom = y + h - 4;

            ctx.method_44379(x + 2, contentY, x + w - 2, contentBottom);

            if (DynamicIslandMod.settingsTab == 0) {
                // KEYBINDS TAB
                String[][] keys = {
                    {"L", "Loomie AI"},
                    {"M", "Expand Music"},
                    {"K", "Lyrics"},
                    {"`", "Play/Pause"},
                    {"[", "Previous Track"},
                    {"]", "Next Track"},
                    {"N", "Notifications"},
                    {"G", "Settings"},
                    {"T", "Media Viewer"}
                };
                int ky = contentY + 2;
                for (String[] pair : keys) {
                    // Key badge
                    int kw = font.method_1727(pair[0]) + 6;
                    drawRoundedRect(ctx, x + 12, ky - 1, kw, 11, 3, ((int)(0xDD * settingsProgress) << 24) | 0x333333);
                    ctx.method_25303(font, pair[0], x + 15, ky + 1, (pa << 24) | 0x9B7DFF);
                    ctx.method_25303(font, pair[1], x + 12 + kw + 6, ky + 1, titleColor);
                    ky += 14;
                }
            } else if (DynamicIslandMod.settingsTab == 1) {
                // NOTIFICATIONS TAB - toggles
                String[][] toggles = {
                    {"Low Health", "toggleLowHealth"},
                    {"Low Hunger", "toggleLowHunger"},
                    {"Durability", "toggleDurability"},
                    {"Player Nearby", "togglePlayerNearby"},
                    {"Whisper/DM", "toggleWhisper"},
                    {"Biome Change", "toggleBiome"},
                    {"Inventory Full", "toggleInventoryFull"}
                };
                int ty = contentY + 2;
                for (String[] toggle : toggles) {
                    boolean val = getToggle(toggle[1]);
                    // Checkbox
                    int cbX = x + 12;
                    int cbY = ty;
                    drawRoundedRect(ctx, cbX, cbY, 9, 9, 2, ((int)(0xDD * settingsProgress) << 24) | 0x333333);
                    if (val) {
                        ctx.method_25294(cbX + 2, cbY + 2, cbX + 7, cbY + 7, (pa << 24) | 0x9B7DFF);
                    }
                    ctx.method_25303(font, toggle[0], cbX + 14, cbY + 1, titleColor);

                    // Handle toggle clicks
                    if (DynamicIslandMod.settingsClickPending) {
                        int cx = DynamicIslandMod.settingsClickX;
                        int cy = DynamicIslandMod.settingsClickY;
                        if (cx >= cbX && cx <= cbX + 100 && cy >= cbY - 1 && cy <= cbY + 10) {
                            setToggle(toggle[1], !val);
                        }
                    }
                    ty += 14;
                }
            } else if (DynamicIslandMod.settingsTab == 2) {
                // INVENTORY TAB
                int iy = contentY + 4;
                ctx.method_25303(font, "Inventory Preset", x + 12, iy, titleColor);
                iy += 14;

                if (DynamicIslandMod.hasInventoryPreset) {
                    ctx.method_25303(font, "Layout saved \u2713", x + 12, iy, (pa << 24) | 0x44DD44);
                } else {
                    ctx.method_25303(font, "No layout saved", x + 12, iy, dimColor);
                }
                iy += 16;

                // Save button
                int btnX = x + 12;
                int btnW = font.method_1727("Save Current Layout") + 12;
                drawRoundedRect(ctx, btnX, iy, btnW, 14, 4, ((int)(0xDD * settingsProgress) << 24) | 0x2A2A2A);
                ctx.method_25303(font, "Save Current Layout", btnX + 6, iy + 3, (pa << 24) | 0x9B7DFF);

                if (DynamicIslandMod.settingsClickPending) {
                    int cx = DynamicIslandMod.settingsClickX;
                    int cy = DynamicIslandMod.settingsClickY;
                    if (cx >= btnX && cx <= btnX + btnW && cy >= iy && cy <= iy + 14) {
                        saveInventoryLayout();
                    }
                }
            } else if (DynamicIslandMod.settingsTab == 3) {
                // THEMES TAB
                int ty = contentY + 4;
                ctx.method_25303(font, "Island Theme", x + 12, ty, titleColor);
                ty += 16;

                for (int i = 0; i < ThemeManager.getThemeCount(); i++) {
                    ThemeManager.Theme t = ThemeManager.themes[i];
                    boolean isActive = (i == ThemeManager.currentIndex);

                    // Color swatch
                    int swatchX = x + 12;
                    drawRoundedRect(ctx, swatchX, ty, 12, 12, 3, 0xFF000000 | t.bgColor);
                    if (t.borderGlow != 0) {
                        drawRoundedRect(ctx, swatchX - 1, ty - 1, 14, 14, 4, t.borderGlow);
                        drawRoundedRect(ctx, swatchX, ty, 12, 12, 3, 0xFF000000 | t.bgColor);
                    }
                    // Accent dot
                    ctx.method_25294(swatchX + 4, ty + 4, swatchX + 8, ty + 8, t.accentColor);

                    // Theme name
                    String tName = t.name;
                    int nameColor = isActive ? ((pa << 24) | 0x9B7DFF) : titleColor;
                    ctx.method_25303(font, tName, swatchX + 18, ty + 2, nameColor);

                    // Active indicator
                    if (isActive) {
                        String check = " ✓";
                        ctx.method_25303(font, check, swatchX + 18 + font.method_1727(tName), ty + 2, (pa << 24) | 0x44DD44);
                    }

                    // Click to select
                    if (DynamicIslandMod.settingsClickPending) {
                        int cx = DynamicIslandMod.settingsClickX;
                        int cy = DynamicIslandMod.settingsClickY;
                        if (cx >= swatchX && cx <= swatchX + 180 && cy >= ty - 2 && cy <= ty + 14) {
                            ThemeManager.setTheme(i);
                        }
                    }
                    ty += 16;
                }
            }

            ctx.method_44380();

            // Consume click
            DynamicIslandMod.settingsClickPending = false;
        }

        // ════════════════════════════════════════════════
        // MEDIA VIEWER PANEL (Redesigned — Mouse-First)
        // ════════════════════════════════════════════════
        if (mediaOpen && mediaProgress > 0.01f) {
            int ma = (int)(0xFF * mediaProgress);
            int mx = mouseX, my = mouseY;

            // ══ IN-GAME BROWSER MODE ══
            if (InGameBrowser.isActive) {
                // Update panel coordinates for the browser
                InGameBrowser.panelX = x;
                InGameBrowser.panelY = y;
                InGameBrowser.panelW = w;
                InGameBrowser.panelH = h;

                int tabBarH = 16;
                int pad = 4;

                // Browser area (inside the panel, below tab bar)
                int bx = x + pad;
                int by = y + tabBarH + pad;
                int bw = w - pad * 2;
                int bh = h - tabBarH - pad * 2;
                InGameBrowser.browserX = bx;
                InGameBrowser.browserY = by;
                InGameBrowser.browserW = bw;
                InGameBrowser.browserH = bh;

                // Tab bar
                if (InGameBrowser.activeMode == InGameBrowser.Mode.MEDIA) {
                    int tabY = y + 3;
                    // YouTube tab
                    String ytLabel = "YouTube";
                    int ytW = font.method_1727(ytLabel) + 10;
                    int ytX = x + 6;
                    boolean ytActive = "youtube".equals(InGameBrowser.activeTab);
                    drawRoundedRect(ctx, ytX, tabY, ytW, 12, 4, (ma << 24) | (ytActive ? 0xFF0000 : 0x333333));
                    ctx.method_25303(font, ytLabel, ytX + 5, tabY + 2, (ma << 24) | 0xFFFFFF);

                    // Twitch tab
                    String twLabel = "Twitch";
                    int twW = font.method_1727(twLabel) + 10;
                    int twX = ytX + ytW + 3;
                    boolean twActive = "twitch".equals(InGameBrowser.activeTab);
                    drawRoundedRect(ctx, twX, tabY, twW, 12, 4, (ma << 24) | (twActive ? 0x9146FF : 0x333333));
                    ctx.method_25303(font, twLabel, twX + 5, tabY + 2, (ma << 24) | 0xFFFFFF);

                    // Tab click handling
                    boolean hasClick = TwitchScreen.clickPending;
                    if (hasClick) {
                        int clickX = TwitchScreen.clickX, clickY = TwitchScreen.clickY;
                        if (clickY >= tabY && clickY < tabY + 12) {
                            if (clickX >= ytX && clickX < ytX + ytW) InGameBrowser.switchTab("youtube");
                            else if (clickX >= twX && clickX < twX + twW) InGameBrowser.switchTab("twitch");
                        }
                        TwitchScreen.clickPending = false;
                    }

                    // ESC hint
                    String hint = "ESC";
                    ctx.method_25303(font, hint, x + w - font.method_1727(hint) - 6, tabY + 2, (ma << 24) | 0x666666);
                } else {
                    // General browser tab
                    int tabY = y + 3;
                    ctx.method_25303(font, "Browser", x + 8, tabY + 2, (ma << 24) | 0x4285F4);
                    String hint = "ESC to close";
                    ctx.method_25303(font, hint, x + w - font.method_1727(hint) - 6, tabY + 2, (ma << 24) | 0x666666);
                }

                // Render browser texture or status
                int texId = InGameBrowser.getTextureID();
                if (texId != 0 && bw > 0 && bh > 0) {
                    // Draw browser content via GL texture
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    RenderSystem.setShaderColor(1f, 1f, 1f, mediaProgress);
                    GL11.glBindTexture(GL11.GL_TEXTURE_2D, texId);

                    var tessellator = class_289.method_1348();
                    var buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);
                    var matrix = ctx.method_51448().method_23760().method_23761();
                    int a = (int)(255 * mediaProgress);
                    buffer.method_22918(matrix, bx, by + bh, 0).method_22913(0, 1).method_1336(255, 255, 255, a);
                    buffer.method_22918(matrix, bx + bw, by + bh, 0).method_22913(1, 1).method_1336(255, 255, 255, a);
                    buffer.method_22918(matrix, bx + bw, by, 0).method_22913(1, 0).method_1336(255, 255, 255, a);
                    buffer.method_22918(matrix, bx, by, 0).method_22913(0, 0).method_1336(255, 255, 255, a);
                    class_286.method_43433(buffer.method_60800());

                    RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                    RenderSystem.disableBlend();

                    // Resize browser if dimensions changed
                    InGameBrowser.resizeBrowser();
                } else if (InGameBrowser.statusMessage != null) {
                    // Show status message (MCEF downloading, not available, etc.)
                    int msgY = by + bh / 2 - 10;
                    ctx.method_25300(font, InGameBrowser.statusMessage, x + w / 2, msgY, (ma << 24) | 0xFFAAAA);
                    if (!InGameBrowser.isMcefAvailable) {
                        ctx.method_25300(font, "Install from modrinth.com/mod/mcef", x + w / 2, msgY + 12, (ma << 24) | 0x888888);
                    } else if (!InGameBrowser.isMcefInitialized) {
                        ctx.method_25300(font, "Please wait...", x + w / 2, msgY + 12, (ma << 24) | 0x888888);
                    }
                } else {
                    ctx.method_25300(font, "Loading...", x + w / 2, by + bh / 2, (ma << 24) | 0xCCCCCC);
                }

                // Blocked site toast
                if (InGameBrowser.blockedMessage != null && System.currentTimeMillis() < InGameBrowser.blockedMessageUntil) {
                    int msgW2 = font.method_1727(InGameBrowser.blockedMessage) + 14;
                    int msgX2 = x + (w - msgW2) / 2;
                    int msgY2 = y + h - 18;
                    drawRoundedRect(ctx, msgX2, msgY2, msgW2, 14, 4, (ma << 24) | 0xCC0000);
                    ctx.method_25300(font, InGameBrowser.blockedMessage, x + w / 2, msgY2 + 3, (ma << 24) | 0xFFFFFF);
                }

            // ══ ORIGINAL MEDIA VIEWER (search + player) ══
            } else {

            boolean isSearchTab = "SEARCH".equals(MediaViewer.activeTab);

            // Consume scroll
            double scroll = TwitchScreen.scrollDelta;
            TwitchScreen.scrollDelta = 0;

            // Check for pending click
            boolean hasClick = TwitchScreen.clickPending;
            int cx = TwitchScreen.clickX, cy = TwitchScreen.clickY;

            if (isSearchTab) {
                // ══ SEARCH VIEW — Card Layout ══
                int headerY = y + 6;

                // Source filter tabs (clickable pills)
                String[] sources = {"All", "YouTube", "Twitch"};
                String[] sourceKeys = {"all", "youtube", "twitch"};
                int[] sourceColors = {0xCCCCCC, 0xFF0000, 0x9146FF};
                int tabX = x + 8;
                for (int si = 0; si < sources.length; si++) {
                    int tw = font.method_1727(sources[si]) + 10;
                    int tabH = 12;
                    boolean isActive = MediaViewer.searchSource.equals(sourceKeys[si]);
                    boolean hovered = mx >= tabX && mx < tabX + tw && my >= headerY && my < headerY + tabH;

                    // Tab pill background
                    if (isActive) {
                        drawRoundedRect(ctx, tabX, headerY, tw, tabH, 6, (ma << 24) | sourceColors[si]);
                        ctx.method_25303(font, sources[si], tabX + 5, headerY + 2, (ma << 24) | 0xFFFFFF);
                    } else {
                        int tabBgAlpha = hovered ? 0x30 : 0x15;
                        drawRoundedRect(ctx, tabX, headerY, tw, tabH, 6, ((int)(tabBgAlpha * mediaProgress) << 24) | 0xFFFFFF);
                        int textAlpha = hovered ? 0xBB : 0x77;
                        ctx.method_25303(font, sources[si], tabX + 5, headerY + 2, ((int)(textAlpha * mediaProgress) << 24) | 0xCCCCCC);
                    }

                    // Tab click
                    if (hasClick && cx >= tabX && cx < tabX + tw && cy >= headerY && cy < headerY + tabH) {
                        MediaViewer.searchSource = sourceKeys[si];
                        hasClick = false;
                    }
                    tabX += tw + 4;
                }

                // Search input field
                int inY = headerY + 16;
                int inX = x + 8;
                int inW = w - 16;
                int inputH = 16;
                boolean searchHovered = mx >= inX && mx < inX + inW && my >= inY && my < inY + inputH;
                int searchBg = searchHovered ? 0x222222 : 0x1A1A1A;
                drawRoundedRect(ctx, inX, inY, inW, inputH, 8, ((int)(0xCC * mediaProgress) << 24) | searchBg);
                // Light border
                drawRoundedRectOutline(ctx, inX, inY, inW, inputH, 8, ((int)(0x10 * mediaProgress) << 24) | 0xFFFFFF);

                String searchText = MediaViewer.searchQuery;
                if (searchText.isEmpty()) {
                    ctx.method_25303(font, "Search YouTube & Twitch...", inX + 8, inY + 4, ((int)(0x44 * mediaProgress) << 24) | 0x666666);
                } else {
                    int maxSW = inW - 20;
                    String display = searchText;
                    if (font.method_1727(display) > maxSW) {
                        display = "..." + searchText.substring(searchText.length() - 25);
                    }
                    ctx.method_25303(font, display, inX + 8, inY + 4, (ma << 24) | 0xFFFFFF);
                    if (System.currentTimeMillis() % 1000 < 500) {
                        int cursorXp = inX + 8 + font.method_1727(display);
                        ctx.method_25294(cursorXp, inY + 3, cursorXp + 1, inY + 13, (ma << 24) | 0xFFFFFF);
                    }
                }

                // Results area
                int resultsTop = inY + inputH + 6;
                int resultsBottom = y + h - 22;

                if (MediaViewer.isSearching) {
                    String loadText = "Searching" + ".".repeat((int)(System.currentTimeMillis() / 400 % 4));
                    ctx.method_25303(font, loadText,
                        x + w / 2 - font.method_1727(loadText) / 2,
                        resultsTop + 30,
                        (ma << 24) | 0x888888);
                } else if (MediaViewer.searchResults.isEmpty() && !MediaViewer.searchQuery.isEmpty()) {
                    ctx.method_25303(font, "No results found",
                        x + w / 2 - font.method_1727("No results found") / 2,
                        resultsTop + 10,
                        ((int)(0x66 * mediaProgress) << 24) | 0x888888);
                } else if (MediaViewer.searchResults.isEmpty()) {
                    // Empty state — no hint text, just a clean search bar
                } else {
                    // Render paginated search results as cards
                    ctx.method_44379(x + 2, resultsTop, x + w - 2, resultsBottom);
                    java.util.List<MediaViewer.SearchResult> pageResults = MediaViewer.getPageResults();
                    int thumbW = 48;
                    int thumbH = 27; // 16:9
                    int itemH = thumbH + 9;
                    int ry = resultsTop;

                    for (int ri = 0; ri < pageResults.size(); ri++) {
                        if (ry + itemH > resultsBottom + 10) break;
                        MediaViewer.SearchResult item = pageResults.get(ri);
                        int absIdx = MediaViewer.absoluteIndex(ri);

                        // Card background with hover
                        boolean cardHovered = mx >= x + 6 && mx < x + w - 6 && my >= ry && my < ry + itemH - 2;
                        if (cardHovered) {
                            drawRoundedRect(ctx, x + 6, ry, w - 12, itemH - 2, 6, ((int)(0x18 * mediaProgress) << 24) | 0xFFFFFF);
                            // Left accent bar on hover
                            int accentColor = "twitch".equals(item.source) ? 0x9146FF : 0xFF0000;
                            ctx.method_25294(x + 6, ry + 2, x + 8, ry + itemH - 4, (ma << 24) | accentColor);
                        }

                        // Click to select
                        if (hasClick && cx >= x + 6 && cx < x + w - 6 && cy >= ry && cy < ry + itemH - 2) {
                            MediaViewer.selectResult(absIdx);
                            hasClick = false;
                        }

                        // Thumbnail
                        int thumbX = x + 12;
                        int thumbY2 = ry + 3;
                        class_2960 thumbId = ThumbnailCache.get(item.thumbnail);
                        if (thumbId != null) {
                            ctx.method_25290(thumbId, thumbX, thumbY2, 0, 0, thumbW, thumbH, thumbW, thumbH);
                        } else {
                            // Gradient placeholder
                            int dotColor = "twitch".equals(item.source) ? 0x9146FF : 0xFF0000;
                            drawRoundedRect(ctx, thumbX, thumbY2, thumbW, thumbH, 3, ((int)(0x40 * mediaProgress) << 24) | 0x181820);
                            drawFilledCircle(ctx, thumbX + thumbW / 2, thumbY2 + thumbH / 2, 3, (ma << 24) | dotColor);
                        }

                        // Title
                        int textX = thumbX + thumbW + 6;
                        String itemTitle = item.title;
                        int maxTitleW = (x + w) - textX - 50;
                        if (font.method_1727(itemTitle) > maxTitleW) {
                            while (font.method_1727(itemTitle + "...") > maxTitleW && itemTitle.length() > 1)
                                itemTitle = itemTitle.substring(0, itemTitle.length() - 1);
                            itemTitle += "...";
                        }
                        int titleColor = cardHovered ? ((ma << 24) | 0xFFFFFF) : ((int)(0xCC * mediaProgress) << 24) | 0xDDDDDD;
                        ctx.method_25303(font, itemTitle, textX, ry + 4, titleColor);

                        // Channel name
                        String meta = item.channel != null && !item.channel.isEmpty() ? item.channel : "";
                        if (font.method_1727(meta) > maxTitleW) {
                            meta = meta.substring(0, Math.min(meta.length(), 20)) + "...";
                        }
                        ctx.method_25303(font, meta, textX, ry + 15, ((int)(0x55 * mediaProgress) << 24) | 0x888888);

                        // Duration badge
                        if (item.duration != null && !item.duration.isEmpty()) {
                            int badgeColor = "LIVE".equals(item.duration) ? 0xFF0000 : 0x333333;
                            String badge = item.duration;
                            int bw = font.method_1727(badge) + 6;
                            drawRoundedRect(ctx, x + w - bw - 10, ry + 5, bw, 10, 4, (ma << 24) | badgeColor);
                            ctx.method_25303(font, badge, x + w - bw - 7, ry + 6, (ma << 24) | 0xFFFFFF);
                        }

                        ry += itemH;
                    }
                    ctx.method_44380();

                    // Pagination footer
                    int totalPages = MediaViewer.getTotalPages();
                    if (totalPages > 1) {
                        int footY = y + h - 18;
                        String pageText = "Page " + (MediaViewer.searchPage + 1) + " of " + totalPages;
                        int ptw = font.method_1727(pageText);
                        ctx.method_25303(font, pageText, x + w / 2 - ptw / 2, footY, ((int)(0x88 * mediaProgress) << 24) | 0xAAAAAA);

                        // Prev button
                        String prev = "<";
                        int prevX = x + w / 2 - ptw / 2 - 16;
                        boolean prevHover = mx >= prevX && mx < prevX + 10 && my >= footY - 1 && my < footY + 10;
                        boolean prevEnabled = MediaViewer.searchPage > 0;
                        int prevColor = prevEnabled ? (prevHover ? 0xFFFFFF : 0xAAAAAA) : 0x444444;
                        ctx.method_25303(font, prev, prevX, footY, ((int)((prevEnabled ? 0xFF : 0x44) * mediaProgress) << 24) | prevColor);
                        if (hasClick && prevEnabled && cx >= prevX && cx < prevX + 10 && cy >= footY - 1 && cy < footY + 10) {
                            MediaViewer.prevPage();
                            hasClick = false;
                        }

                        // Next button
                        String next = ">";
                        int nextX = x + w / 2 + ptw / 2 + 8;
                        boolean nextHover = mx >= nextX && mx < nextX + 10 && my >= footY - 1 && my < footY + 10;
                        boolean nextEnabled = MediaViewer.searchPage < totalPages - 1;
                        int nextColor = nextEnabled ? (nextHover ? 0xFFFFFF : 0xAAAAAA) : 0x444444;
                        ctx.method_25303(font, next, nextX, footY, ((int)((nextEnabled ? 0xFF : 0x44) * mediaProgress) << 24) | nextColor);
                        if (hasClick && nextEnabled && cx >= nextX && cx < nextX + 10 && cy >= footY - 1 && cy < footY + 10) {
                            MediaViewer.nextPage();
                            hasClick = false;
                        }
                    }
                }

            } else {
                // ══ PLAYER VIEW — Clickable Controls ══
                boolean isTwitch = MediaViewer.mediaType == MediaViewer.MediaType.TWITCH;
                boolean isYoutube = MediaViewer.mediaType == MediaViewer.MediaType.YOUTUBE;
                int headerColor = isTwitch ? 0x9146FF : isYoutube ? 0xFF0000 : 0xCCCCCC;

                int headerY = y + 6;

                // Back button (clickable)
                String backBtn = "< Back";
                int backW = font.method_1727(backBtn) + 8;
                boolean backHover = mx >= x + 6 && mx < x + 6 + backW && my >= headerY - 1 && my < headerY + 11;
                int backBg = backHover ? 0x30 : 0x15;
                drawRoundedRect(ctx, x + 6, headerY - 1, backW, 12, 6, ((int)(backBg * mediaProgress) << 24) | 0xFFFFFF);
                ctx.method_25303(font, backBtn, x + 10, headerY + 1, ((int)((backHover ? 0xFF : 0x99) * mediaProgress) << 24) | 0xCCCCCC);
                if (hasClick && cx >= x + 6 && cx < x + 6 + backW && cy >= headerY - 1 && cy < headerY + 11) {
                    MediaViewer.stopStream();
                    DynamicIslandMod.isMediaOpen = true;
                    MediaViewer.activeTab = "SEARCH";
                    hasClick = false;
                }

                // Source badge
                String sourceLabel = isTwitch ? "TWITCH" : isYoutube ? "YOUTUBE" : "MEDIA";
                int slW = font.method_1727(sourceLabel) + 8;
                drawRoundedRect(ctx, x + 6 + backW + 4, headerY - 1, slW, 12, 6, (ma << 24) | headerColor);
                ctx.method_25303(font, sourceLabel, x + 6 + backW + 8, headerY + 1, (ma << 24) | 0xFFFFFF);

                // Title
                String title = MediaViewer.currentTitle.isEmpty() ? MediaViewer.currentSource : MediaViewer.currentTitle;
                int titleStartX = x + 6 + backW + 4 + slW + 6;
                int titleMaxW2 = (x + w - 8) - titleStartX;
                if (font.method_1727(title) > titleMaxW2) {
                    while (font.method_1727(title + "...") > titleMaxW2 && title.length() > 1)
                        title = title.substring(0, title.length() - 1);
                    title += "...";
                }
                ctx.method_25303(font, title, titleStartX, headerY + 1, (ma << 24) | 0xFFFFFF);

                // Video area
                int videoTop = headerY + 16;
                int videoW = w - 20;
                int videoH = (int)(videoW * 9f / 16f);
                int videoX = x + 10;

                MediaViewer.preRender();

                if (MediaViewer.hasTexture() && MediaViewer.getTextureIdentifier() != null) {
                    ctx.method_25290(MediaViewer.getTextureIdentifier(), videoX, videoTop, 0, 0, videoW, videoH, videoW, videoH);
                } else {
                    drawRoundedRect(ctx, videoX, videoTop, videoW, videoH, 4, (ma << 24) | 0x111111);
                    String placeholder = MediaViewer.watermediaAvailable ? "Loading stream..." : "Install WATERMeDIA mod";
                    ctx.method_25303(font, placeholder,
                        videoX + videoW / 2 - font.method_1727(placeholder) / 2,
                        videoTop + videoH / 2 - 4,
                        ((int)(0x88 * mediaProgress) << 24) | 0x888888);
                }

                if (isYoutube) {
                    long pos = MediaViewer.getPosition();
                    long dur = MediaViewer.getDuration();
                    boolean playing = MediaViewer.isPlaying();

                    // Progress bar (clickable + scrubbable)
                    int barY = videoTop + videoH + 4;
                    int barX2 = x + 10;
                    int barW = w - 20;
                    int barH = 4;

                    // Bar track
                    drawRoundedRect(ctx, barX2, barY, barW, barH, 2, ((int)(0x30 * mediaProgress) << 24) | 0xFFFFFF);
                    // Filled portion
                    if (dur > 0) {
                        int filled = (int)(barW * pos / (float) dur);
                        if (filled > 0) drawRoundedRect(ctx, barX2, barY, filled, barH, 2, (ma << 24) | 0xFF0000);
                        // Scrub dot
                        drawFilledCircle(ctx, barX2 + filled, barY + 2, 3, (ma << 24) | 0xFFFFFF);
                    }

                    // Progress bar click to seek (strict Y bounds: only within bar ± 3px)
                    if (hasClick && cx >= barX2 && cx < barX2 + barW && cy >= barY - 3 && cy < barY + barH + 3 && dur > 0) {
                        float ratio = (float)(cx - barX2) / barW;
                        ratio = Math.max(0, Math.min(1, ratio));
                        MediaViewer.seekTo((long)(ratio * dur));
                        hasClick = false;
                    }
                    // Drag scrubbing (strict Y bounds)
                    if (TwitchScreen.isDragging && TwitchScreen.dragX >= barX2 && TwitchScreen.dragX < barX2 + barW
                        && TwitchScreen.dragY >= barY - 3 && TwitchScreen.dragY < barY + barH + 3 && dur > 0) {
                        float ratio = (float)(TwitchScreen.dragX - barX2) / barW;
                        ratio = Math.max(0, Math.min(1, ratio));
                        MediaViewer.seekTo((long)(ratio * dur));
                    }

                    // Time display (row 1 — under progress bar)
                    int timeY = barY + barH + 3;
                    String timeStr = formatMs(pos) + " / " + formatMs(dur);
                    ctx.method_25303(font, timeStr, x + 10, timeY, ((int)(0x88 * mediaProgress) << 24) | 0xAAAAAA);

                    // Control buttons row (row 2 — under time)
                    int ctrlY = timeY + 12;
                    int btnH = 14;
                    int btnSpacing = 4;

                    // << 5s button
                    String rewBtn = "<< 5s";
                    int rewW = font.method_1727(rewBtn) + 10;
                    int rewX = x + 10;
                    boolean rewHover = mx >= rewX && mx < rewX + rewW && my >= ctrlY && my < ctrlY + btnH;
                    drawRoundedRect(ctx, rewX, ctrlY, rewW, btnH, 6, ((int)((rewHover ? 0x30 : 0x18) * mediaProgress) << 24) | 0xFFFFFF);
                    ctx.method_25303(font, rewBtn, rewX + 5, ctrlY + 3, ((int)((rewHover ? 0xFF : 0xAA) * mediaProgress) << 24) | 0xCCCCCC);
                    if (hasClick && cx >= rewX && cx < rewX + rewW && cy >= ctrlY && cy < ctrlY + btnH) {
                        MediaViewer.seek(-5000);
                        hasClick = false;
                    }

                    // Play/Pause button
                    String playBtn = playing ? " || " : "  >  ";
                    int playW = font.method_1727(playBtn) + 10;
                    int playX = rewX + rewW + btnSpacing;
                    boolean playHover = mx >= playX && mx < playX + playW && my >= ctrlY && my < ctrlY + btnH;
                    drawRoundedRect(ctx, playX, ctrlY, playW, btnH, 6, ((int)((playHover ? 0x40 : 0x25) * mediaProgress) << 24) | 0xFFFFFF);
                    ctx.method_25303(font, playBtn, playX + 5, ctrlY + 3, (ma << 24) | 0xFFFFFF);
                    if (hasClick && cx >= playX && cx < playX + playW && cy >= ctrlY && cy < ctrlY + btnH) {
                        MediaViewer.togglePause();
                        hasClick = false;
                    }

                    // >> 5s button
                    String fwdBtn = "5s >>";
                    int fwdW = font.method_1727(fwdBtn) + 10;
                    int fwdX = playX + playW + btnSpacing;
                    boolean fwdHover = mx >= fwdX && mx < fwdX + fwdW && my >= ctrlY && my < ctrlY + btnH;
                    drawRoundedRect(ctx, fwdX, ctrlY, fwdW, btnH, 6, ((int)((fwdHover ? 0x30 : 0x18) * mediaProgress) << 24) | 0xFFFFFF);
                    ctx.method_25303(font, fwdBtn, fwdX + 5, ctrlY + 3, ((int)((fwdHover ? 0xFF : 0xAA) * mediaProgress) << 24) | 0xCCCCCC);
                    if (hasClick && cx >= fwdX && cx < fwdX + fwdW && cy >= ctrlY && cy < ctrlY + btnH) {
                        MediaViewer.seek(5000);
                        hasClick = false;
                    }

                    // Volume (right side of control row)
                    String volIcon = MediaViewer.isMuted() ? "Mx" : "Vol";
                    int volLabelW = font.method_1727(volIcon);
                    int vBarW = 40;
                    int totalVolW = volLabelW + 4 + vBarW;
                    int volX = x + w - totalVolW - 10;
                    boolean volIconHover = mx >= volX && mx < volX + volLabelW + 4 && my >= ctrlY && my < ctrlY + btnH;
                    ctx.method_25303(font, volIcon, volX, ctrlY + 3, ((int)((volIconHover ? 0xFF : 0x88) * mediaProgress) << 24) | 0xAAAAAA);
                    if (hasClick && cx >= volX && cx < volX + volLabelW + 4 && cy >= ctrlY && cy < ctrlY + btnH) {
                        MediaViewer.toggleMute();
                        hasClick = false;
                    }

                    // Volume bar (inline with volume label)
                    int vBarX = volX + volLabelW + 4;
                    int vBarY = ctrlY + 5;
                    drawRoundedRect(ctx, vBarX, vBarY, vBarW, 4, 2, ((int)(0x30 * mediaProgress) << 24) | 0xFFFFFF);
                    int volFilled = (int)(vBarW * MediaViewer.getVolume() / 100f);
                    if (volFilled > 0) drawRoundedRect(ctx, vBarX, vBarY, volFilled, 4, 2, (ma << 24) | 0xFFFFFF);
                    // Volume bar click
                    if (hasClick && cx >= vBarX && cx < vBarX + vBarW && cy >= vBarY - 4 && cy < vBarY + 8) {
                        int newVol = (int)(100f * (cx - vBarX) / vBarW);
                        MediaViewer.setVolume(Math.max(0, Math.min(100, newVol)));
                        hasClick = false;
                    }

                } else if (isTwitch) {
                    // Twitch chat area (below video)
                    int chatSepY = videoTop + videoH + 4;
                    ctx.method_25294(x + 8, chatSepY, x + w - 8, chatSepY + 1, ((int)(0x15 * mediaProgress) << 24) | 0xFFFFFF);

                    int chatTop = chatSepY + 3;
                    int inputH2 = 18;
                    int chatBottom = y + h - inputH2 - 6;

                    ctx.method_44379(x + 2, chatTop, x + w - 2, chatBottom);
                    java.util.List<TwitchChat.ChatMsg> msgs = TwitchChat.messages;
                    int lineH = 10;
                    int my2 = chatBottom - 2;

                    for (int idx = 0; idx < msgs.size() && my2 > chatTop - lineH; idx++) {
                        TwitchChat.ChatMsg msg = msgs.get(idx);
                        int msgColor;
                        try {
                            msgColor = (ma << 24) | Integer.parseInt(msg.color.replace("#", ""), 16);
                        } catch (Exception e) {
                            msgColor = (ma << 24) | 0xFFFFFF;
                        }

                        String prefix = msg.username + ": ";
                        String fullMsg = prefix + msg.message;
                        int maxMsgW = w - 24;
                        if (font.method_1727(fullMsg) > maxMsgW) {
                            while (font.method_1727(fullMsg + "...") > maxMsgW && fullMsg.length() > prefix.length())
                                fullMsg = fullMsg.substring(0, fullMsg.length() - 1);
                            fullMsg += "...";
                        }

                        my2 -= lineH;
                        ctx.method_25303(font, prefix, x + 10, my2, msgColor);
                        String msgText = msg.message;
                        int maxBodyLen = fullMsg.length() - prefix.length();
                        if (maxBodyLen < msgText.length()) msgText = msgText.substring(0, Math.max(0, maxBodyLen));
                        ctx.method_25303(font, msgText,
                            x + 10 + font.method_1727(prefix), my2, (ma << 24) | 0xDDDDDD);
                    }
                    ctx.method_44380();

                    int inY3 = y + h - inputH2 - 3;
                    int inX3 = x + 8;
                    int inW3 = w - 16;
                    drawRoundedRect(ctx, inX3, inY3, inW3, inputH2, 9, ((int)(0xDD * mediaProgress) << 24) | 0x2A2A2A);

                    String inputText = TwitchChat.inputText;
                    if (inputText.isEmpty()) {
                        ctx.method_25303(font, "Type a message...", inX3 + 8, inY3 + 5, ((int)(0x44 * mediaProgress) << 24) | 0x666666);
                    } else {
                        int maxInputW = inW3 - 20;
                        String display = inputText;
                        if (font.method_1727(display) > maxInputW) {
                            display = "..." + inputText.substring(inputText.length() - 20);
                        }
                        ctx.method_25303(font, display, inX3 + 8, inY3 + 5, (ma << 24) | 0xFFFFFF);
                        if (System.currentTimeMillis() % 1000 < 500) {
                            int cursorX2 = inX3 + 8 + font.method_1727(display);
                            ctx.method_25294(cursorX2, inY3 + 4, cursorX2 + 1, inY3 + 14, (ma << 24) | 0xFFFFFF);
                        }
                    }
                }
            }

            // Consume click
            TwitchScreen.clickPending = false;
            } // end of else (original media viewer)
        }

        // ════════════════════════════════════════════════
        // APP DRAWER (Control Center)
        // ════════════════════════════════════════════════
        if (isAppDrawerOpen && appDrawerProgress > 0.01f) {
            int da = (int)(0xFF * appDrawerProgress);

            // 3x2 grid of app tiles
            String[] appNames = {"Media", "Loomie", "Notifs", "Waypoints", "Timers", "Settings", "Browser"};
            int[] appColors = {0xFF0000, 0x66FCF1, 0xFFB800, 0x4CAF50, 0xAB47BC, 0x78909C, 0x4285F4};
            // Text-based pixel icons
            String[] appIcons = {">", "?", "!", "@", "~", "*", "W"};

            int cols = 3;
            int tileW = 60;
            int tileH = 54;
            int gapX = 8;
            int gapY = 6;
            int gridW = cols * tileW + (cols - 1) * gapX;
            int gridX = x + (w - gridW) / 2;
            int gridY = y + 12;

            int amx = mouseX, amy = mouseY;
            boolean dClick = AppDrawerScreen.clickPending;
            int dcx = AppDrawerScreen.clickX, dcy = AppDrawerScreen.clickY;

            for (int i = 0; i < appNames.length; i++) {
                int col = i % cols;
                int row = i / cols;
                int tx = gridX + col * (tileW + gapX);
                int ty = gridY + row * (tileH + gapY);

                boolean hover = amx >= tx && amx < tx + tileW && amy >= ty && amy < ty + tileH;
                int tileBg = hover ? 0x20 : 0x10;
                drawRoundedRect(ctx, tx, ty, tileW, tileH, 8, ((int)(tileBg * appDrawerProgress) << 24) | 0xFFFFFF);
                // Tile border
                if (hover) {
                    drawRoundedRectOutline(ctx, tx, ty, tileW, tileH, 8, ((int)(0x20 * appDrawerProgress) << 24) | appColors[i]);
                }

                // Icon text symbol
                String icon = appIcons[i];
                int iconW = font.method_1727(icon);
                ctx.method_25303(font, icon, tx + (tileW - iconW) / 2, ty + 14, (da << 24) | appColors[i]);

                // Label
                int labelW = font.method_1727(appNames[i]);
                ctx.method_25303(font, appNames[i], tx + (tileW - labelW) / 2, ty + tileH - 14, ((int)((hover ? 0xFF : 0xAA) * appDrawerProgress) << 24) | 0xDDDDDD);

                // Tile click handling
                if (dClick && dcx >= tx && dcx < tx + tileW && dcy >= ty && dcy < ty + tileH) {
                    // Close drawer first
                    isAppDrawerOpen = false;
                    DynamicIslandMod.isAppDrawerOpen = false;
                    if (client.field_1755 instanceof AppDrawerScreen) {
                        client.field_1755.method_25419();
                    }

                    // Open the corresponding panel
                    switch (i) {
                        case 0: // Media — opens in-game YouTube/Twitch browser
                            DynamicIslandMod.isMediaOpen = true;
                            InGameBrowser.openMedia();
                            break;
                        case 1: // Loomie AI
                            DynamicIslandMod.isPebbleOpen = true;
                            client.method_1507(new PebbleScreen());
                            break;
                        case 2: // Notifications
                            DynamicIslandMod.notifCenterTab = 0;
                            DynamicIslandMod.isNotifCenterOpen = true;
                            client.method_1507(new NotifCenterScreen());
                            break;
                        case 3: // Waypoints
                            DynamicIslandMod.notifCenterTab = 1;
                            DynamicIslandMod.isNotifCenterOpen = true;
                            client.method_1507(new NotifCenterScreen());
                            break;
                        case 4: // Timers
                            DynamicIslandMod.notifCenterTab = 2;
                            DynamicIslandMod.isNotifCenterOpen = true;
                            client.method_1507(new NotifCenterScreen());
                            break;
                        case 5: // Settings
                            DynamicIslandMod.isSettingsOpen = true;
                            client.method_1507(new SettingsScreen());
                            break;
                        case 6: // Browser — opens filtered general browser
                            InGameBrowser.openGeneral();
                            break;
                    }
                    dClick = false;
                }
            }

            AppDrawerScreen.clickPending = false;
        }

        // ══════════════════════════════════════════════
        // BOSS BARS (below the pill)
        // ══════════════════════════════════════════════
        if (!BossBarTracker.activeBars.isEmpty()) {
            int bossY = y + h + 4;
            for (BossBarTracker.BossBarInfo bar : BossBarTracker.activeBars) {
                int barW = Math.max(w, 160);
                int barX = screenW / 2 - barW / 2;

                ctx.method_25303(font, bar.name, screenW / 2 - font.method_1727(bar.name) / 2, bossY, 0xFFFFFF);
                bossY += 10;

                drawRoundedRect(ctx, barX, bossY, barW, 5, 2, 0xCC000000);
                int fillW = (int)(barW * bar.percent);
                if (fillW > 0) drawRoundedRect(ctx, barX, bossY, fillW, 5, 2, bar.getBarColor());
                bossY += 10;
            }
        }
    }

    // ══════════════════════════════════════════════════
    // DRAWING HELPERS
    // ══════════════════════════════════════════════════

    private void drawCircleMask(class_332 ctx, int x, int y, int size, int bgColor) {
        int r = size / 2;
        int cx = x + r;
        for (int row = 0; row < size; row++) {
            int dy = r - row;
            int dx = (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - (double) dy * dy)));
            int leftEdge = cx - dx;
            int rightEdge = cx + dx;
            if (leftEdge > x) ctx.method_25294(x, y + row, leftEdge, y + row + 1, bgColor);
            if (rightEdge < x + size) ctx.method_25294(rightEdge, y + row, x + size, y + row + 1, bgColor);
        }
    }

    private void drawFilledCircle(class_332 ctx, int x, int y, int size, int color) {
        int r = size / 2;
        int cx = x + r;
        for (int row = 0; row < size; row++) {
            int dy = r - row;
            int dx = (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - (double) dy * dy)));
            ctx.method_25294(cx - dx, y + row, cx + dx, y + row + 1, color);
        }
    }

    /**
     * Draws an item at the given position, scaled to itemSize, with a durability bar underneath.
     */
    private void drawCombatItem(class_332 ctx, class_1799 stack, int ix, int iy, int itemSize) {
        if (stack != null && !stack.method_7960()) {
            ctx.method_51448().method_22903();
            float scale = itemSize / 16f;
            ctx.method_51448().method_46416(ix, iy, 0);
            ctx.method_51448().method_22905(scale, scale, 1.0f);
            ctx.method_51427(stack, 0, 0);
            ctx.method_51448().method_22909();

            // Durability bar
            if (stack.method_7963() && stack.method_7919() > 0) {
                float durPct = 1.0f - (float)stack.method_7919() / stack.method_7936();
                int durColor = durPct > 0.5f ? 0xFF44DD44 : durPct > 0.25f ? 0xFFDDDD44 : 0xFFDD4444;
                int durW = Math.max(1, (int)(itemSize * durPct));
                ctx.method_25294(ix, iy + itemSize + 1, ix + itemSize, iy + itemSize + 3, 0xFF222222);
                ctx.method_25294(ix, iy + itemSize + 1, ix + durW, iy + itemSize + 3, durColor);
            } else if (stack.method_7963()) {
                ctx.method_25294(ix, iy + itemSize + 1, ix + itemSize, iy + itemSize + 3, 0xFF44DD44);
            }
        } else {
            drawRoundedRect(ctx, ix, iy, itemSize, itemSize, 2, 0x20FFFFFF);
        }
    }

    public static void drawRoundedRect(class_332 ctx, int x, int y, int w, int h, int r, int color) {
        if (r <= 0) { ctx.method_25294(x, y, x + w, y + h, color); return; }
        r = Math.min(r, Math.min(w / 2, h / 2));
        ctx.method_25294(x + r, y, x + w - r, y + h, color);
        ctx.method_25294(x, y + r, x + r, y + h - r, color);
        ctx.method_25294(x + w - r, y + r, x + w, y + h - r, color);
        for (int row = 0; row < r; row++) {
            int dy = r - row;
            int dx = (int) Math.round(r - Math.sqrt((double) r * r - (double) dy * dy));
            ctx.method_25294(x + dx, y + row, x + r, y + row + 1, color);
            ctx.method_25294(x + w - r, y + row, x + w - dx, y + row + 1, color);
            ctx.method_25294(x + dx, y + h - 1 - row, x + r, y + h - row, color);
            ctx.method_25294(x + w - r, y + h - 1 - row, x + w - dx, y + h - row, color);
        }
    }

    public static void drawRoundedRectOutline(class_332 ctx, int x, int y, int w, int h, int r, int color) {
        if (r <= 0) {
            ctx.method_25294(x, y, x + w, y + 1, color); // top
            ctx.method_25294(x, y + h - 1, x + w, y + h, color); // bottom
            ctx.method_25294(x, y, x + 1, y + h, color); // left
            ctx.method_25294(x + w - 1, y, x + w, y + h, color); // right
            return;
        }
        r = Math.min(r, Math.min(w / 2, h / 2));
        // Top edge
        ctx.method_25294(x + r, y, x + w - r, y + 1, color);
        // Bottom edge
        ctx.method_25294(x + r, y + h - 1, x + w - r, y + h, color);
        // Left edge
        ctx.method_25294(x, y + r, x + 1, y + h - r, color);
        // Right edge
        ctx.method_25294(x + w - 1, y + r, x + w, y + h - r, color);
        // Corner arcs (1px outline)
        for (int row = 0; row < r; row++) {
            int dy = r - row;
            int dx = (int) Math.round(r - Math.sqrt((double) r * r - (double) dy * dy));
            int dx2 = (int) Math.round(r - Math.sqrt((double) r * r - (double) (dy - 1) * (dy - 1)));
            // Top-left
            ctx.method_25294(x + dx, y + row, x + Math.max(dx + 1, dx2), y + row + 1, color);
            // Top-right
            ctx.method_25294(x + w - Math.max(dx + 1, dx2), y + row, x + w - dx, y + row + 1, color);
            // Bottom-left
            ctx.method_25294(x + dx, y + h - 1 - row, x + Math.max(dx + 1, dx2), y + h - row, color);
            // Bottom-right
            ctx.method_25294(x + w - Math.max(dx + 1, dx2), y + h - 1 - row, x + w - dx, y + h - row, color);
        }
    }

    private void drawEqBar(class_332 ctx, int x, int y, int barW, int maxH, int color,
                           long time, double speed, double phase) {
        double t = (time / 80.0) * speed + phase;
        int barH = (int)(4 + (Math.sin(t) * 0.5 + 0.5) * (maxH - 4));
        int barY = y + maxH - barH;
        ctx.method_25294(x, barY, x + barW, y + maxH, color);
    }

    private String formatMs(long ms) {
        long sec = ms / 1000;
        return (sec / 60) + ":" + String.format("%02d", sec % 60);
    }

    private void loadAlbumArt(String url) {
        if (albumLoading) return;
        albumLoading = true;
        currentAlbumUrl = url;

        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
                HttpResponse<InputStream> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofInputStream());

                if (resp.statusCode() == 200) {
                    java.awt.image.BufferedImage buffered = javax.imageio.ImageIO.read(resp.body());
                    if (buffered == null) { albumLoading = false; return; }

                    int imgW = buffered.getWidth();
                    int imgH = buffered.getHeight();

                    // Extract dominant color
                    long totalR = 0, totalG = 0, totalB = 0;
                    int samples = 0;
                    int step = Math.max(1, Math.min(imgW, imgH) / 20);
                    for (int sy = 0; sy < imgH; sy += step) {
                        for (int sx = 0; sx < imgW; sx += step) {
                            int argb = buffered.getRGB(sx, sy);
                            totalR += (argb >> 16) & 0xFF;
                            totalG += (argb >> 8) & 0xFF;
                            totalB += argb & 0xFF;
                            samples++;
                        }
                    }
                    if (samples > 0) {
                        int avgR = Math.max(5, Math.min(40, (int)(totalR / samples * 0.15f)));
                        int avgG = Math.max(5, Math.min(40, (int)(totalG / samples * 0.15f)));
                        int avgB = Math.max(5, Math.min(40, (int)(totalB / samples * 0.15f)));
                        albumTintColor = (avgR << 16) | (avgG << 8) | avgB;
                    }

                    class_1011 image = new class_1011(imgW, imgH, false);
                    for (int py = 0; py < imgH; py++) {
                        for (int px = 0; px < imgW; px++) {
                            int argb = buffered.getRGB(px, py);
                            int a = (argb >> 24) & 0xFF;
                            int r = (argb >> 16) & 0xFF;
                            int g = (argb >> 8) & 0xFF;
                            int b = argb & 0xFF;
                            image.method_4305(px, py, (a << 24) | (b << 16) | (g << 8) | r);
                        }
                    }

                    class_310.method_1551().execute(() -> {
                        try {
                            if (albumTextureId != null) {
                                class_310.method_1551().method_1531().method_4615(albumTextureId);
                            }
                            class_1043 texture = new class_1043(image);
                            albumTextureId = class_2960.method_60655("cobble", "album_art");
                            class_310.method_1551().method_1531().method_4616(albumTextureId, texture);
                        } catch (Exception e) {
                            System.err.println("[DynamicIsland] Failed to register album art: " + e.getMessage());
                        }
                        albumLoading = false;
                    });
                } else {
                    albumLoading = false;
                }
            } catch (Exception e) {
                System.err.println("[DynamicIsland] Failed to download album art: " + e.getMessage());
                albumLoading = false;
            }
        }, "DI-AlbumArt").start();
    }

    // ══════════════════════════════════════════════════
    // PEBBLE HELPERS
    // ══════════════════════════════════════════════════

    private int pebbleBubbleH(class_327 f, String text, int maxW) {
        return pebbleWrap(f, text, maxW - 14).size() * 10 + 10;
    }

    private java.util.List<String> pebbleWrap(class_327 f, String text, int maxW) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        if (text == null || text.isEmpty()) { lines.add(""); return lines; }
        for (String para : text.split("\n")) {
            if (para.trim().isEmpty()) continue;
            StringBuilder cur = new StringBuilder();
            for (String w : para.split(" ")) {
                if (w.isEmpty()) continue;
                if (f.method_1727(w) > maxW) {
                    if (cur.length() > 0) { lines.add(cur.toString()); cur = new StringBuilder(); }
                    StringBuilder part = new StringBuilder();
                    for (char c : w.toCharArray()) {
                        if (f.method_1727(part.toString() + c) > maxW) { lines.add(part.toString()); part = new StringBuilder(); }
                        part.append(c);
                    }
                    if (part.length() > 0) cur = part;
                    continue;
                }
                String test = cur.length() > 0 ? cur + " " + w : w;
                if (f.method_1727(test) > maxW) { lines.add(cur.toString()); cur = new StringBuilder(w); }
                else { if (cur.length() > 0) cur.append(" "); cur.append(w); }
            }
            if (cur.length() > 0) lines.add(cur.toString());
        }
        if (lines.isEmpty()) lines.add("");
        return lines;
    }

    // ══════════════════════════════════════════════════
    // NOTIFICATION / SETTINGS HELPERS
    // ══════════════════════════════════════════════════

    private String relativeTime(long deltaMs) {
        long sec = deltaMs / 1000;
        if (sec < 5) return "now";
        if (sec < 60) return sec + "s";
        long min = sec / 60;
        if (min < 60) return min + "m";
        long hr = min / 60;
        return hr + "h";
    }

    private boolean getToggle(String name) {
        return switch (name) {
            case "toggleLowHealth" -> DynamicIslandMod.toggleLowHealth;
            case "toggleLowHunger" -> DynamicIslandMod.toggleLowHunger;
            case "toggleDurability" -> DynamicIslandMod.toggleDurability;
            case "togglePlayerNearby" -> DynamicIslandMod.togglePlayerNearby;
            case "toggleWhisper" -> DynamicIslandMod.toggleWhisper;
            case "toggleBiome" -> DynamicIslandMod.toggleBiome;
            case "toggleInventoryFull" -> DynamicIslandMod.toggleInventoryFull;
            default -> true;
        };
    }

    private void setToggle(String name, boolean val) {
        switch (name) {
            case "toggleLowHealth" -> DynamicIslandMod.toggleLowHealth = val;
            case "toggleLowHunger" -> DynamicIslandMod.toggleLowHunger = val;
            case "toggleDurability" -> DynamicIslandMod.toggleDurability = val;
            case "togglePlayerNearby" -> DynamicIslandMod.togglePlayerNearby = val;
            case "toggleWhisper" -> DynamicIslandMod.toggleWhisper = val;
            case "toggleBiome" -> DynamicIslandMod.toggleBiome = val;
            case "toggleInventoryFull" -> DynamicIslandMod.toggleInventoryFull = val;
        }
    }

    private void saveInventoryLayout() {
        net.minecraft.class_310 client = net.minecraft.class_310.method_1551();
        if (client.field_1724 == null) return;
        int[] layout = new int[36]; // main inventory slots
        for (int i = 0; i < 36; i++) {
            net.minecraft.class_1799 stack = client.field_1724.method_31548().field_7547.get(i);
            layout[i] = stack.method_7960() ? -1 : net.minecraft.class_7923.field_41178.method_10206(stack.method_7909());
        }
        DynamicIslandMod.savedInventoryLayout = layout;
        DynamicIslandMod.hasInventoryPreset = true;
    }
}
