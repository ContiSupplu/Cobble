package com.cobble.dynamicisland;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Lightweight transparent screen — only captures keyboard input for Pebble.
 * All visual rendering happens in DynamicIslandHud.
 */
public class PebbleScreen extends class_437 {

    private class_342 inputField;

    public PebbleScreen() {
        super(class_2561.method_43470("Pebble"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        // Invisible input field — we just need it for keystroke capture
        int fieldW = 250;
        int fieldX = this.field_22789 / 2 - fieldW / 2;
        int fieldY = this.field_22790; // offscreen — HUD renders the visual

        this.inputField = new class_342(
                this.field_22793, fieldX, fieldY, fieldW, 12,
                class_2561.method_43470("")
        );
        this.inputField.method_1880(256);
        this.inputField.method_1858(false);
        this.inputField.method_1868(0xEEEEEE);
        this.method_37063(this.inputField);
        this.method_48265(this.inputField);

        // Restore any in-progress text
        this.inputField.method_1852(DynamicIslandMod.pebbleInputText);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            String q = this.inputField.method_1882().trim();
            if (!q.isEmpty() && !DynamicIslandMod.pebbleWaiting) {
                DynamicIslandMod.pebbleWaiting = true;
                DynamicIslandMod.pebbleMessages.add(
                    new DynamicIslandMod.PebbleChatMsg(q, true)
                );
                this.inputField.method_1852("");
                DynamicIslandMod.pebbleInputText = "";
                DynamicIslandMod.pebbleScroll = 0;

                // Send to launcher
                String json = "{\"type\":\"pebble_question\",\"text\":\"" +
                        q.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + "\"}";
                if (LauncherWebSocket.getInstance() != null && LauncherWebSocket.getInstance().isOpen()) {
                    LauncherWebSocket.getInstance().send(json);
                } else {
                    DynamicIslandMod.addPebbleAnswer("Not connected to Cobble Launcher.");
                }
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            DynamicIslandMod.isPebbleOpen = false;
            DynamicIslandMod.pebbleInputText = "";
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        boolean result = super.method_25400(chr, modifiers);
        DynamicIslandMod.pebbleInputText = this.inputField.method_1882();
        return result;
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        boolean result = super.method_16803(keyCode, scanCode, modifiers);
        DynamicIslandMod.pebbleInputText = this.inputField.method_1882();
        return result;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        DynamicIslandMod.pebbleScroll += (int)(verticalAmount * 20);
        return true;
    }

    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Fully transparent — no dimming, game stays visible
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Don't call super.render — we don't want the TextField to render
        // All visuals are handled by DynamicIslandHud
    }

    @Override
    public boolean method_25421() { return false; }
}
