package com.cobble.dynamicisland;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_742;
import net.minecraft.class_746;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class GameAlerts {

    // ── Death tracking ─────────────────────────────
    public static class_2338 deathPos = null;
    public static String deathDimension = null;
    public static boolean deathActive = false;

    // ── Persistent alert ───────────────────────────
    public static String persistentText = null;
    public static String persistentType = null;
    public static boolean persistentIsAlert = false;

    // ── Biome subtitle (footnote, not notification) ─
    public static String biomeSubtitle = null;
    public static long biomeSubtitleUntil = 0;

    // ── Song peek (show music briefly during death) ─
    public static String lastSongTitle = null;
    public static long songPeekUntil = 0;

    // ── Internal state ─────────────────────────────
    private static boolean wasDead = false;
    private static float lastHealth = 20f;
    private static boolean lowHungerShown = false;
    private static boolean inventoryFullShown = false;
    private static int lastTrackedDurability = -1;
    private static String lastTrackedItemName = null;
    private static String lastBiome = null;
    private static final Set<UUID> knownPlayers = new HashSet<>();
    private static boolean playersInitialized = false;

    // ── Player head for notification ───────────────
    public static class_2960 notificationHeadTexture = null;
    public static long notificationHeadUntil = 0;

    // ── Thresholds ─────────────────────────────────
    private static final int HEALTH_THRESHOLD = 6;
    private static final int HUNGER_THRESHOLD = 6;
    private static final int DURABILITY_USES_WARN = 10;
    private static final int EFFECT_SECONDS_WARN = 10;

    public static void clearPersistent() {
        persistentText = null;
        persistentType = null;
        persistentIsAlert = false;
        deathPos = null;
        deathDimension = null;
        deathActive = false;
        biomeSubtitle = null;
        biomeSubtitleUntil = 0;
        notificationHeadTexture = null;
        notificationHeadUntil = 0;
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) return;

            class_746 player = client.field_1724;

            checkDeath(player);

            // ── Song peek detection ────────────────
            LauncherState state = DynamicIslandMod.currentState;
            if (state != null && state.spotify != null && state.spotify.title != null) {
                if (!state.spotify.title.equals(lastSongTitle)) {
                    lastSongTitle = state.spotify.title;
                    if (deathActive) {
                        songPeekUntil = System.currentTimeMillis() + 5000;
                    }
                }
            }

            // ── Persistent alerts (priority order) ──
            String newText = null;
            String newType = null;
            boolean newIsAlert = false;

            String elytra = checkElytraFlight(player);
            if (elytra != null) {
                newText = elytra; newType = "elytra"; newIsAlert = true;
            }

            if (newText == null) {
                String effect = checkEffectExpiring(player);
                if (effect != null) {
                    newText = effect; newType = "effect"; newIsAlert = true;
                }
            }

            if (newText == null) {
                String dura = checkDurability(player);
                if (dura != null) {
                    newText = dura; newType = "durability"; newIsAlert = true;
                }
            }

            if (newText == null && deathActive && deathPos != null && !player.method_29504()) {
                newText = getDeathDisplay(player);
                newType = "death";
                newIsAlert = false;
            }

            persistentText = newText;
            persistentType = newType;
            persistentIsAlert = newIsAlert;

            // ── One-shot checks (1/sec) ────────────
            if (client.field_1687.method_8510() % 20 == 0) {
                checkHealth(player);
                checkHunger(player);
                checkInventoryFull(player);
                checkDeathProximity(player);
                checkBiomeChange(player);
                checkNearbyPlayers(client);
            }
        });
    }

    // ══════════════════════════════════════════════════
    // PERSISTENT ALERTS
    // ══════════════════════════════════════════════════

    private static String checkElytraFlight(class_746 player) {
        if (!player.method_6128()) return null;
        class_1799 chest = player.method_6118(class_1304.field_6174);
        if (chest.method_7960() || !chest.method_31574(class_1802.field_8833)) return null;
        int remaining = chest.method_7936() - chest.method_7919();
        if (remaining > DURABILITY_USES_WARN) return null;
        return "Elytra: " + remaining + "s flight left!";
    }

    private static String checkEffectExpiring(class_746 player) {
        Collection<class_1293> effects = player.method_6026();
        String worstName = null;
        int worstSeconds = Integer.MAX_VALUE;

        for (class_1293 effect : effects) {
            int seconds = effect.method_5584() / 20;
            if (seconds <= EFFECT_SECONDS_WARN && seconds > 0) {
                String name = effect.method_5579().comp_349().method_5560().getString();
                if (seconds < worstSeconds) {
                    worstSeconds = seconds;
                    worstName = name;
                }
            }
        }
        return worstName != null ? worstName + ": " + worstSeconds + "s left" : null;
    }

    private static boolean armorWarned_head = false;
    private static boolean armorWarned_chest = false;
    private static boolean armorWarned_legs = false;
    private static boolean armorWarned_feet = false;

    private static String checkDurability(class_746 player) {
        // Tools: only show when player is actively using (swinging hand)
        if (player.field_6252) {
            class_1799 held = player.method_6047();
            if (!held.method_7960() && held.method_7963()) {
                int remaining = held.method_7936() - held.method_7919();
                if (remaining > 0 && remaining <= DURABILITY_USES_WARN) {
                    return held.method_7964().getString() + ": " + remaining + " uses left";
                }
            }
        }

        // Armor: one-shot notification when close to broken, then reset when replaced
        checkArmorSlot(player, class_1304.field_6169, "armorWarned_head");
        checkArmorSlot(player, class_1304.field_6174, "armorWarned_chest");
        checkArmorSlot(player, class_1304.field_6172, "armorWarned_legs");
        checkArmorSlot(player, class_1304.field_6166, "armorWarned_feet");

        return null;
    }

    private static void checkArmorSlot(class_746 player, class_1304 slot, String flag) {
        class_1799 stack = player.method_6118(slot);
        boolean warned = switch (flag) {
            case "armorWarned_head" -> armorWarned_head;
            case "armorWarned_chest" -> armorWarned_chest;
            case "armorWarned_legs" -> armorWarned_legs;
            default -> armorWarned_feet;
        };

        if (stack.method_7960() || !stack.method_7963()) {
            // Reset warning when armor removed/replaced
            setArmorWarned(flag, false);
            return;
        }

        int remaining = stack.method_7936() - stack.method_7919();
        if (remaining <= DURABILITY_USES_WARN && remaining > 0 && !warned) {
            setArmorWarned(flag, true);
            DynamicIslandMod.triggerNotification(stack.method_7964().getString() + ": " + remaining + " uses left!", "durability");
        } else if (remaining > DURABILITY_USES_WARN) {
            setArmorWarned(flag, false);
        }
    }

    private static void setArmorWarned(String flag, boolean val) {
        switch (flag) {
            case "armorWarned_head" -> armorWarned_head = val;
            case "armorWarned_chest" -> armorWarned_chest = val;
            case "armorWarned_legs" -> armorWarned_legs = val;
            default -> armorWarned_feet = val;
        }
    }

    // ══════════════════════════════════════════════════
    // ONE-SHOT NOTIFICATIONS
    // ══════════════════════════════════════════════════

    private static void checkDeath(class_746 player) {
        if (player.method_29504() && !wasDead) {
            deathPos = player.method_24515();
            deathDimension = getDimensionName(player);
            deathActive = true;
            wasDead = true;
            lastHealth = 20f;
        } else if (!player.method_29504() && wasDead) {
            wasDead = false;
            lastHealth = player.method_6032();
        }
    }

    private static void checkHealth(class_746 player) {
        float health = player.method_6032();
        if (health <= HEALTH_THRESHOLD && health > 0 && health < lastHealth && DynamicIslandMod.toggleLowHealth) {
            DynamicIslandMod.triggerNotification("Low Health! " + String.format("%.0f", health / 2) + " hearts", "health");
        }
        lastHealth = health;
    }

    private static void checkHunger(class_746 player) {
        int food = player.method_7344().method_7586();
        if (food <= HUNGER_THRESHOLD && !lowHungerShown && DynamicIslandMod.toggleLowHunger) {
            lowHungerShown = true;
            DynamicIslandMod.triggerNotification("Low Hunger! " + food / 2 + " left", "hunger");
        } else if (food > HUNGER_THRESHOLD + 2) {
            lowHungerShown = false;
        }
    }

    private static void checkInventoryFull(class_746 player) {
        boolean full = true;
        for (int i = 0; i < player.method_31548().field_7547.size(); i++) {
            if (player.method_31548().field_7547.get(i).method_7960()) { full = false; break; }
        }
        if (full && !inventoryFullShown && DynamicIslandMod.toggleInventoryFull) {
            inventoryFullShown = true;
            DynamicIslandMod.triggerNotification("Inventory Full!", "inventory");
        } else if (!full) {
            inventoryFullShown = false;
        }
    }

    private static void checkDeathProximity(class_746 player) {
        if (!deathActive || deathPos == null || player.method_29504()) return;
        String currentDim = getDimensionName(player);
        if (!currentDim.equals(deathDimension)) return; // Wrong dimension

        double dist = Math.sqrt(player.method_24515().method_10262(deathPos));
        if (dist < 5) {
            deathActive = false;
            DynamicIslandMod.triggerNotification("Reached death location!", "death");
        }
    }

    private static void checkBiomeChange(class_746 player) {
        String biome = player.method_37908().method_23753(player.method_24515())
                .method_40230().map(k -> k.method_29177().method_12832()).orElse("unknown");
        String clean = biome.replace("_", " ");
        clean = clean.substring(0, 1).toUpperCase() + clean.substring(1);

        if (lastBiome == null) { lastBiome = clean; return; }
        if (!clean.equals(lastBiome)) {
            lastBiome = clean;
            // Set as subtitle footnote for 4 seconds (no notification sound)
            biomeSubtitle = clean;
            biomeSubtitleUntil = System.currentTimeMillis() + 4000;
        }
    }

    /** Returns true if biome subtitle should be shown */
    public static boolean hasBiomeSubtitle() {
        if (biomeSubtitle == null) return false;
        if (System.currentTimeMillis() > biomeSubtitleUntil) {
            biomeSubtitle = null;
            return false;
        }
        return true;
    }

    /** Returns true if a player head should be shown with current notification */
    public static boolean hasNotificationHead() {
        return notificationHeadTexture != null && System.currentTimeMillis() < notificationHeadUntil;
    }

    // ══════════════════════════════════════════════════
    // PLAYER PROXIMITY
    // ══════════════════════════════════════════════════

    private static void checkNearbyPlayers(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return;

        List<class_742> players = client.field_1687.method_18456();

        // First tick: silently populate the set with all current players
        if (!playersInitialized) {
            for (class_742 p : players) {
                knownPlayers.add(p.method_5667());
            }
            playersInitialized = true;
            return;
        }

        // Track current UUIDs to remove departed players
        Set<UUID> currentUuids = new HashSet<>();

        for (class_742 p : players) {
            UUID uuid = p.method_5667();
            currentUuids.add(uuid);

            // Skip self
            if (uuid.equals(client.field_1724.method_5667())) continue;

            // New player detected!
            if (!knownPlayers.contains(uuid)) {
                knownPlayers.add(uuid);
                String name = p.method_5477().getString();

                // Get their skin texture for the head icon
                class_640 entry = client.method_1562() != null
                        ? client.method_1562().method_2871(uuid) : null;
                if (entry != null && entry.method_52810() != null) {
                    notificationHeadTexture = entry.method_52810().comp_1626();
                    notificationHeadUntil = System.currentTimeMillis() + 4500; // Show head for notification duration
                }

                if (DynamicIslandMod.togglePlayerNearby) {
                    DynamicIslandMod.triggerNotification(name + " is nearby", "player");
                }
            }
        }

        // Remove players who left
        knownPlayers.retainAll(currentUuids);
        // Always keep self
        knownPlayers.add(client.field_1724.method_5667());
    }

    // ══════════════════════════════════════════════════
    // DEATH LOCATION — Find My style
    // ══════════════════════════════════════════════════

    private static String getDeathDisplay(class_746 player) {
        if (deathPos == null) return null;

        String currentDim = getDimensionName(player);

        // Wrong dimension — guide to portal
        if (!currentDim.equals(deathDimension)) {
            return "Find a portal to " + deathDimension;
        }

        // Same dimension — show distance + direction
        double dx = deathPos.method_10263() - player.method_23317();
        double dz = deathPos.method_10260() - player.method_23321();
        int dist = (int) Math.sqrt(dx * dx + dz * dz);

        double angle = Math.toDegrees(Math.atan2(-dx, dz));
        float yaw = player.method_36454();
        double rel = ((angle - yaw) % 360 + 360) % 360;

        String dir;
        if (rel >= 337.5 || rel < 22.5)   dir = "ahead";
        else if (rel < 67.5)              dir = "ahead-right";
        else if (rel < 112.5)             dir = "to your right";
        else if (rel < 157.5)             dir = "behind-right";
        else if (rel < 202.5)             dir = "behind you";
        else if (rel < 247.5)             dir = "behind-left";
        else if (rel < 292.5)             dir = "to your left";
        else                              dir = "ahead-left";

        return dist + " blocks · " + dir;
    }

    public static String getDeathCoords() {
        if (deathPos == null) return "";
        return deathPos.method_10263() + " " + deathPos.method_10264() + " " + deathPos.method_10260();
    }

    /** Returns true if song peek is active (new song during death tracking) */
    public static boolean isSongPeekActive() {
        return deathActive && songPeekUntil > 0 && System.currentTimeMillis() < songPeekUntil;
    }

    // ══════════════════════════════════════════════════
    // MC TIME
    // ══════════════════════════════════════════════════

    public static String getMcTimeDisplay() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return null;
        long time = client.field_1687.method_8532();
        long day = time / 24000 + 1;
        long dayTime = time % 24000;
        String icon = dayTime < 12000 ? "Day" : dayTime < 13000 ? "Dusk" : dayTime < 23000 ? "Night" : "Dawn";
        return "Day " + day + " · " + icon;
    }

    private static String getDimensionName(class_746 player) {
        String dim = player.method_37908().method_27983().method_29177().method_12832();
        if (dim.contains("nether")) return "Nether";
        if (dim.contains("end")) return "The End";
        return "Overworld";
    }
}
